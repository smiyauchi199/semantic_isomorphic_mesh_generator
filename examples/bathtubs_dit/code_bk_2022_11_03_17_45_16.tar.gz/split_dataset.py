import json
import random
import sys

import numpy as np


if __name__ == "__main__":

    args = sys.argv

    class_name = args[1]
    all_data_file = "examples/splits/sv2_{}s_all.json".format(class_name)

    with open(all_data_file, 'r') as f:
        all_data = json.load(f)

    for dataset_name in all_data.keys():
        for class_id in all_data[dataset_name].keys():
            model_list = sorted(all_data[dataset_name][class_id])

    num_all_models = len(model_list)
    train_ratio = 0.8
    num_train_models = int(num_all_models * train_ratio)
    # num_train_models = np.floor(num_all_models * train_ratio).astype(np.int)
    print("train vs test is {} vs {}".format(num_train_models, num_all_models-num_train_models))

    # train split
    train_model_list = model_list[:num_train_models]
    json_data = {dataset_name: {}}
    json_data[dataset_name][class_id] = train_model_list
    json_object = json.dumps(json_data, indent=4)
    train_split_file = "examples/splits/sv2_{}s_train.json".format(class_name)
    with open(train_split_file, 'w') as f:
        f.write(json_object)

    # test split
    test_model_list = model_list[num_train_models:]
    json_data = {dataset_name: {}}
    json_data[dataset_name][class_id] = test_model_list
    json_object = json.dumps(json_data, indent=4)
    test_split_file = "examples/splits/sv2_{}s_test.json".format(class_name)
    with open(test_split_file, 'w') as f:
        f.write(json_object)



    # train_data_file = "examples/splits/sv2_{}s_train.json".format(class_name)
    # with open(train_data_file, 'r') as f:
    #     train_data = json.load(f)
    # for dataset_name in train_data.keys():
    #     for class_id in train_data[dataset_name].keys():
    #         train_model_list = sorted(train_data[dataset_name][class_id])

    # test_data_file = "examples/splits/sv2_{}s_test.json".format(class_name)
    # with open(test_data_file, 'r') as f:
    #     test_data = json.load(f)
    # for dataset_name in test_data.keys():
    #     for class_id in test_data[dataset_name].keys():
    #         test_model_list = sorted(test_data[dataset_name][class_id])

    # model_list = sorted(list(set(train_model_list + test_model_list)))
    # json_data = {dataset_name: {}}
    # json_data[dataset_name][class_id] = model_list
    # json_object = json.dumps(json_data, indent=4)
    # all_split_file = "examples/splits/sv2_{}s_all2.json".format(class_name)
    # with open(all_split_file, 'w') as f:
    #     f.write(json_object)

