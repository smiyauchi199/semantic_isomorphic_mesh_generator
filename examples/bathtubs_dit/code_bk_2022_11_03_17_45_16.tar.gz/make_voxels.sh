CUDA=${1}


# CUDA_VISIBLE_DEVICES=3 python generate_training_voxels.py -e examples/cars_dit --debug --start_id 0 --end_id 5000 --octree --keep_normalization
# CUDA_VISIBLE_DEVICES=3 python generate_training_voxels.py -e examples/planes_dit --debug --start_id 0 --end_id 5000 --octree --keep_normalization
# CUDA_VISIBLE_DEVICES=3 python generate_training_voxels.py -e examples/chairs_dit --debug --start_id 0 --end_id 5000 --octree --keep_normalization
# CUDA_VISIBLE_DEVICES=3 python generate_training_voxels.py -e examples/sofas_dit --debug --start_id 0 --end_id 5000 --octree --keep_normalization
# CUDA_VISIBLE_DEVICES=3 python generate_training_voxels.py -e examples/tables_dit --debug --start_id 0 --end_id 5000 --octree --keep_normalization

# class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")
# class_name_list=("chair" "table")
# class_name_list=("bathtub" "bottle" "display")
class_name_list=("bathtub")

for name in ${class_name_list[@]}; 
do
  # CUDA_VISIBLE_DEVICES=${CUDA} python generate_training_voxels.py -e examples/${name}s_dit --debug
  CUDA_VISIBLE_DEVICES=${CUDA} python generate_training_voxels.py -e examples/${name}s_dit --debug --start_id 0 --end_id 2 --octree --keep_normalization
  # cp examples/${name}s_dit/TrainingMeshes/2000/${name}s_64.hdf5 ../voxel2mesh/dataset/${name}/
done

# names=("airplane" "02691156")
# names=("airplane" "02691156" "bathtub" "02808440" "bottle" "02876657" "car" "02958343" "chair" "03001627" "display" "03211117" "knife" "03624134" "pistol" "03948459" "sofa" "04256520" "table" "04379243")
# 
# for (( i=0; i<${#names[@]} ; i+=2 )) ; do
#   echo "${names[i]}" "${names[i+1]}"
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_training_voxels.py -e examples/${names[i]}s_dit --debug --start_id 0 --end_id 1999 --octree --keep_normalization
#   mkdir ../voxel2mesh/dataset/${names[i]}
#   cp examples/${names[i]}s_dit/TrainingMeshes/2000/voxels/${names[i+1]}/${names[i+1]}_64.hdf5 ../voxel2mesh/dataset/${names[i]}
# done
