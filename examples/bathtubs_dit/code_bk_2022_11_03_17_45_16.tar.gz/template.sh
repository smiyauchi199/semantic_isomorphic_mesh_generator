
CUDA=${1}

# class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")
# class_name_list=("bathtub" "display")
# class_name_list=("car" "table")
# class_name_list=("bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")
# class_name_list=("airplane" "bathtub" "bottle")
# class_name_list=("bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")
# class_name_list=("airplane")
# class_name_list=("car")
# class_name_list=("bathtub")
class_name_list=("bathtub" "bottle" "car" "sofa")
# class_name_list=("bathtub" "bottle" "sofa" "chair" "table" "knife" "pistol")
# class_name_list=("bathtub" "bottle" "car" "sofa")

subfix=""
# subfix="_allsteps"
# subfix="_3dn"
# subfix="_pp"

ckpt=2000

# Computing time for generating structured meshes...
# for i in {1..10}
# do
#   for name in ${class_name_list[@]};
#   do
#     CUDA_VISIBLE_DEVICES=${CUDA} python generate_canonical_positions.py -e examples${subfix}/${name}s_dit --start_id 0 --end_id 0 --checkpoint ${ckpt}
#   done
# done

for name in ${class_name_list[@]};
do
  # CUDA_VISIBLE_DEVICES=${CUDA} python generate_template_mesh.py -e examples${subfix}/${name}s_dit --debug --checkpoint ${ckpt}
  # CUDA_VISIBLE_DEVICES=${CUDA} python generate_training_meshes.py -e examples${subfix}/${name}s_dit --debug --start_id 0 --end_id 4 --octree --keep_normalization --checkpoint ${ckpt}
  # CUDA_VISIBLE_DEVICES=${CUDA} python generate_meshes_correspondence.py -e examples${subfix}/${name}s_dit --debug --start_id 0 --end_id 4 --checkpoint ${ckpt}
  # CUDA_VISIBLE_DEVICES=${CUDA} python remove_inner_points_with_sdf.py -e examples${subfix}/${name}s_dit --batch_split 2 --start_id 0 --end_id 4 --checkpoint ${ckpt} -d /data1/itaya/data
  CUDA_VISIBLE_DEVICES=${CUDA} python generate_canonical_positions.py -e examples${subfix}/${name}s_dit --start_id 0 --end_id 1999 --checkpoint ${ckpt}
  # python farthest_point_sampling.py examples/${name}s_dit/TrainingMeshes/2000/ShapeNetV2/ 10000
done


# names=("bathtub" "02808440" "bottle" "02876657" "car" "02958343" "chair" "03001627" "display" "03211117" "knife" "03624134" "pistol" "03948459" "sofa" "04256520" "table" "04379243")
# names=("table" "04379243")
# 
# for (( i=0; i<${#names[@]} ; i+=2 )) ; do
#   echo "${names[i]}" "${names[i+1]}"
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_canonical_positions.py -e examples/${names[i]}s_dit --start_id 0 --end_id 1999
#   python farthest_point_sampling.py examples/${names[i]}s_dit/TrainingMeshes/2000/ShapeNetV2/${names[i+1]} 10000
# done

# names=("0.4" "True" "0.3" "True" "0.5" "False" "0.4" "False" "0.3" "False")
# names=("0.3" "False")
#  
# for (( i=0; i<${#names[@]} ; i+=2 )) ; do
#   echo "${names[i]}" "${names[i+1]}"
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_template_mesh.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --debug
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_training_meshes.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --debug --start_id 0 --end_id 4 --octree --keep_normalization
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_meshes_correspondence.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --debug --start_id 0 --end_id 4
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_canonical_positions.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --start_id 0 --end_id 4
# done

# names=("0.5" "0.001" "0.4" "0.001" "0.3" "0.001" "0.5" "0.01" "0.4" "0.01" "0.3" "0.01")
#  
# for (( i=0; i<${#names[@]} ; i+=2 )) ; do
#   echo "${names[i]}" "${names[i+1]}"
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_template_mesh.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --debug
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_training_meshes.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --debug --start_id 0 --end_id 4 --octree --keep_normalization
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_meshes_correspondence.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --debug --start_id 0 --end_id 4
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_canonical_positions.py -e examples${subfix}/airplanes_dit_${names[i]}_${names[i+1]} --start_id 0 --end_id 4
# done
