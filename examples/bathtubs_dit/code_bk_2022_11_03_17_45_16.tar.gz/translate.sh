
CUDA=${1}

class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")

for name in ${class_name_list[@]};
do
  CUDA_VISIBLE_DEVICES=${CUDA} python translate_npz.py -e examples/${name}s_dit --start_id 0 --end_id 1999
done

