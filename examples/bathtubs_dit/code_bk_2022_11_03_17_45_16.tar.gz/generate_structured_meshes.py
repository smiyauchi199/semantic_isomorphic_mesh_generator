import argparse
import json
import logging
import os
import sys

import numpy as np
import plyfile
import torch
import deep_sdf
import deep_sdf.workspace as ws
import point_cloud_utils as pcu


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write(
            "element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
        fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


def code_to_mesh(experiment_directory, checkpoint, start_id, end_id, batch_split):

    specs_filename = os.path.join(experiment_directory, "specs.json")

    if not os.path.isfile(specs_filename):
        raise Exception(
            'The experiment directory does not include specifications file "specs.json"'
        )

    specs = json.load(open(specs_filename))

    arch = __import__(
        "networks." + specs["NetworkArch"], fromlist=["Generator", "InverseImplicitFun"])

    latent_size = specs["CodeLength"]

    generator = arch.Generator(
        latent_size, **specs["NetworkSpecs"]["generator_kargs"])
    # generator = arch.InverseImplicitFun(latent_size, **specs["NetworkSpecs"]["generator_kargs"])

    generator = torch.nn.DataParallel(generator)

    saved_model_state = torch.load(
        os.path.join(experiment_directory,
                     ws.generator_params_subdir, checkpoint + ".pth")
    )
    saved_model_epoch = saved_model_state["epoch"]

    generator.load_state_dict(saved_model_state["model_state_dict"])

    generator = generator.module.cuda()

    generator.eval()

    latent_vectors = ws.load_pre_trained_latent_vectors(
        experiment_directory, checkpoint)

    # load template mesh
    saved_model_state = torch.load(
        os.path.join(experiment_directory,
                     ws.model_params_subdir, checkpoint + ".pth")
    )
    saved_model_epoch = saved_model_state["epoch"]
    template_filename = os.path.join(experiment_directory,
                                     ws.training_meshes_subdir,
                                     str(saved_model_epoch), 'template')
                                     # kstr(saved_model_epoch), 'template_smg')
                                     # str(saved_model_epoch), 'template_smg_knn')
    logging.info("Loading from %s.ply" % template_filename)
    template = plyfile.PlyData.read(template_filename + ".ply")
    template_v = []  # template.elements[0]
    template_f = []  # template.elements[1]
    for i in range(template.elements[0].count):
        v = template.elements[0][i]
        template_v.append(np.array((v[0], v[1], v[2])))
    for i in range(template.elements[1].count):
        f = template.elements[1][i][0]
        template_f.append(np.array([f[0], f[1], f[2]]))
    template_v = np.asarray(template_v)
    template_f = np.asarray(template_f)
    # template_v, template_f = pcu.load_mesh_vf(template_filename + '.ply')

    train_split_file = specs["TrainSplit"]

    with open(train_split_file, "r") as f:
        train_split = json.load(f)
    for dataset_name in train_split.keys():
        for cate_id in train_split[dataset_name].keys():
            modelIDs = [
                modelID for modelID in train_split[dataset_name][cate_id]]
    print(len(modelIDs), " vs ", len(latent_vectors))

    mesh_dir = os.path.join(
        experiment_directory,
        ws.training_meshes_subdir,
        str(saved_model_epoch),
        'structured_meshes'
    )

    if not os.path.isdir(mesh_dir):
        os.makedirs(mesh_dir)

    for i, latent_vector in enumerate(latent_vectors):
        if i < start_id:
            continue

        print(modelIDs[i])
        mesh_filename = os.path.join(mesh_dir, modelIDs[i])

        lat_vecs = latent_vector.expand(template_v.shape[0], -1)
        xyz = torch.chunk(torch.from_numpy(template_v).float(), batch_split)
        latent_vector = torch.chunk(lat_vecs, batch_split)

        inverse_warped_xyz = []
        for j in range(batch_split):
            with torch.no_grad():
                interm_input = torch.cat(
                    [latent_vector[j], xyz[j]], dim=1).cuda()
                _, _, inverse_warped_xyz_list = generator(interm_input)
                inverse_warped_xyz.append(inverse_warped_xyz_list[-1].cpu())
                # tmp_inverse_warped_xyz = generator(interm_input)
                # inverse_warped_xyz.append(tmp_inverse_warped_xyz.cpu())
        inverse_warped_xyz = np.concatenate(inverse_warped_xyz)

        # store canonical coordinates as rgb color (in float format)
        verts_color = 255 * (0.5 + 0.5 * template_v)
        verts_color = verts_color.astype(np.uint8)
        # write_points_ply(mesh_filename + '_colored.ply',
        #                  inverse_warped_xyz, template_f, verts_color)
        write_points_ply(mesh_filename + '.ply',
                         inverse_warped_xyz, template_f)

        if i >= end_id:
            break


if __name__ == "__main__":

    arg_parser = argparse.ArgumentParser(
        description="Use a trained DeepSDF decoder to generate a mesh given a latent code."
    )
    arg_parser.add_argument(
        "--experiment",
        "-e",
        dest="experiment_directory",
        required=True,
        help="The experiment directory which includes specifications and saved model "
        + "files to use for reconstruction",
    )
    arg_parser.add_argument(
        "--checkpoint",
        "-c",
        dest="checkpoint",
        default="latest",
        help="The checkpoint weights to use. This can be a number indicated an epoch "
        + "or 'latest' for the latest weights (this is the default)",
    )
    arg_parser.add_argument(
        "--start_id",
        dest="start_id",
        type=int,
        default=0,
        help="start_id.",
    )
    arg_parser.add_argument(
        "--end_id",
        dest="end_id",
        type=int,
        default=20,
        help="end_id.",
    )
    arg_parser.add_argument(
        "--batch_split",
        type=int,
        default=1,
        help="This splits the batch into separate subbatches which are "
        + "processed separately, with gradients accumulated across all "
        + "subbatches. This allows for training with large effective batch "
        + "sizes in memory constrained environments.",
    )

    deep_sdf.add_common_args(arg_parser)

    args = arg_parser.parse_args()

    deep_sdf.configure_logging(args)

    code_to_mesh(
        args.experiment_directory,
        args.checkpoint,
        args.start_id,
        args.end_id,
        args.batch_split)
