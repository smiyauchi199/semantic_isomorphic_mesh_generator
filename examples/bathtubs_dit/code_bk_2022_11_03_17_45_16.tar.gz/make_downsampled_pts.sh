
class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")

for name in ${class_name_list[@]};
do
    python3 sample_points.py ${name}
done

