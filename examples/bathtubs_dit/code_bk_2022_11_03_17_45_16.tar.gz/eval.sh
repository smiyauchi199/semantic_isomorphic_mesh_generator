CUDA=${1}

# class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")
class_name_list=("car")

# for name in ${class_name_list[@]};
# do
#   CUDA_VISIBLE_DEVICES=${CUDA} python test_reconstruct_dit.py -e examples/${name}s_dit -c 2000 --split examples/splits/sv2_${name}s_all.json -d /raid/itaya/data --skip --octree
#   # CUDA_VISIBLE_DEVICES=${CUDA} python reconstruct_deep_implicit_templates.py -e examples/${name}s_dit -c 2000 --split examples/splits/sv2_${name}s_all.json -d /raid/itaya/data --skip --octree
#   # CUDA_VISIBLE_DEVICES=${CUDA} python evaluate.py -e examples/cars_dit/${EX_DIR} -c 2000 -s examples/splits/sv2_cars_test.json -d /media/user/itaya/data --debug
# 
# done

# name="car"
name="sofa"
CUDA_VISIBLE_DEVICES=${CUDA} python reconstruct_structured_meshes.py -e examples/${name}s_dit/${EX_DIR} -c latest --split examples/splits/sv2_${name}s_all.json -d /mnt/nas/3DModelDataset/ShapeNet --skip --batch_split 2
