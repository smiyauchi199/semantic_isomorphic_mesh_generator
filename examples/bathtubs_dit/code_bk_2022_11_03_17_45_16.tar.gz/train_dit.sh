# Deep Implicit Templates

CUDA=${1}

# class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")
# class_name_list=("bathtub" "display")
# class_name_list=("airplane")

# for name in ${class_name_list[@]};
# do
#   CUDA_VISIBLE_DEVICES=${CUDA} python train_deep_implicit_templates.py -e examples/${name}s_dit --debug --batch_split 1 -c latest -d /raid/itaya/data
#   # CUDA_VISIBLE_DEVICES=${CUDA} python train_deep_implicit_templates_new.py -e examples/${name}s_dit --debug --batch_split 2 -c latest -d /raid/itaya/data
#   # CUDA_VISIBLE_DEVICES=${CUDA} python train_deep_implicit_templates_exp.py -e examples_allsteps/${name}s_dit --debug --batch_split 1 -c latest -d /raid/itaya/data
#   # CUDA_VISIBLE_DEVICES=${CUDA} python train_deep_implicit_templates_exp.py -e examples_3dn/${name}s_dit --debug --batch_split 4 -c latest -d /raid/itaya/data
# done


# names=("0.4" "True" "0.3" "True" "0.5" "False" "0.4" "False" "0.3" "False")
names=("0.5" "0.001" "0.4" "0.001" "0.3" "0.001" "0.5" "0.01" "0.4" "0.01" "0.3" "0.01")
 
for (( i=0; i<${#names[@]} ; i+=2 )) ; do
  echo "${names[i]}" "${names[i+1]}"
  CUDA_VISIBLE_DEVICES=${CUDA} python train_deep_implicit_templates_exp.py -e examples_pp/airplanes_dit_${names[i]}_${names[i+1]} --debug --batch_split 1 -c latest -d /raid/itaya/data --epsilon ${names[i]} --pp_default False
done
