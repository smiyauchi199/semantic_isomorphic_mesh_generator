import logging
import os
import sys
import tqdm

import numpy as np
import point_cloud_utils as pcu


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


def mesh_to_correspondence():

    input_dir = "/Users/itayakyo/majoring/IIMLab/2021/keypoint/proposed/programs/models/DeepImplicitTemplates-StructuredMesh/examples/airplanes_dit/TrainingMeshes/2000/ShapeNetV2/02691156/"

    check_list = [
        "1021a0914a7207aff927ed529ad90a11",
        "1026dd1b26120799107f68a9cb8e3c",
        "10aa040f470500c6a66ef8df4909ded9",
        "10c7cdfdffe2243b88a89a28f04ce622",
        "10cfc2090a2ade124c3a35cee92bb95b",
    ]

    for i, instance_name in tqdm.tqdm(enumerate(check_list)):

        print('instance_name: ', instance_name)

        mesh_filename_ori = os.path.join(input_dir, instance_name + '_canonical_position_mesh_ori.ply')
        print('mesh_filename_ori: ', mesh_filename_ori)

        v_ori, f_ori = pcu.load_mesh_vf(mesh_filename_ori)

        mesh_filename_warped = os.path.join(input_dir, instance_name + '_canonical_position_mesh_3.ply')
        print('mesh_filename_warped: ', mesh_filename_warped)

        v, f = pcu.load_mesh_vf(mesh_filename_warped)

        # # store canonical coordinates as rgb color (in float format)
        verts_color = 255 * (0.5 + 0.5 * v_ori)
        verts_color = verts_color.astype(np.uint8)
        write_points_ply(mesh_filename_ori + '_colored.ply', v_ori, faces=f_ori, rgb_points=verts_color)
        write_points_ply(mesh_filename_warped + '_colored.ply', v, faces=f, rgb_points=verts_color)
        # write_points_ply(mesh_filename_ori + '_colored.ply', v_ori, faces=f_ori)
        # write_points_ply(mesh_filename_warped + '_colored.ply', v, faces=f)


if __name__ == "__main__":

    mesh_to_correspondence()
