import numpy as np


if __name__ == '__main__':

    filename = 'data/SdfSamples/ShapeNetV2/03001627/1016f4debe988507589aae130c1f06fb.npz'

    data = np.load(filename)

    print(data)
