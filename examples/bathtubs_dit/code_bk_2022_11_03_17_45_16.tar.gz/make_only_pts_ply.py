import os
import sys

import numpy as np
import point_cloud_utils as pcu


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


if __name__ == '__main__':
    args = sys.argv

    class_id = '02691156'
    output_dir = os.path.join('data', class_id, 'models')
    exts = '.ply'

    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    files = sorted(os.listdir(output_dir))
    instance_list = [f for f in files if f[-4:] == '.obj']
    print(instance_list)

    for i, f in enumerate(instance_list):
        if i == 10:
            break

        modelId = os.path.basename(f).split('.')[0]

        pts = pcu.load_mesh_v(output_dir + '/' + f)
        print(pts.shape)

        write_points_ply(output_dir + '/' + modelId +
                         '_pts' + exts, pts)