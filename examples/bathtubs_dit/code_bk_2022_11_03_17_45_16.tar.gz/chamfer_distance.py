"""
Calculation Chamfer distance for checking SMG results.
"""

import sys

import numpy as np
import point_cloud_utils as pcu
import torch

from chamferdist import ChamferDistance

def load_ori(filename):
    def split_line(line):
        line = line.rstrip().split(' ')
        return line[0], line[1], line[2]

    with open(filename, 'r') as f:
        lines = f.readlines()

    cloud = []
    for i in range(int(lines[0])):
        cloud.extend(split_line(lines[i+1]))
    cloud = np.reshape(np.array(cloud, dtype=np.float32), (-1, 3))

    return cloud

if __name__ == '__main__':

    args = sys.argv

    target_file = args[1]
    source_file = args[2]

    stage = args[3]

    # load target file
    if target_file[-4:] in ['.obj', '.ply']:
        target_cloud = torch.from_numpy(np.array(pcu.load_mesh_v(target_file), dtype=np.float32)).unsqueeze(0)
    else:
        target_cloud = torch.from_numpy(load_ori(target_file)).unsqueeze(0)

    # load source file
    # source_cloud = torch.from_numpy(load_ori(source_file)).unsqueeze(0)
    source_cloud = torch.from_numpy(np.array(pcu.load_mesh_v(source_file), dtype=np.float32)).unsqueeze(0)

    chamferDist = ChamferDistance()

    cdist = 0.5 * chamferDist(source_cloud, target_cloud, bidirectional=True)
    print("{}: {}".format(stage, cdist.detach().cpu().item()))

