#!/usr/bin/env python3
# Copyright 2004-present Facebook. All Rights Reserved.

import logging
import argparse
import json
import numpy as np
import os
import torch
import plyfile
import sys

import deep_sdf
import deep_sdf.workspace as ws
import shapenet
import torch.utils.data as data_utils


def write_points_obj(fname, points, colors=None):

    with open(fname, 'w') as f:

        num = points.shape[0]
        for i in range(0, num):
            if colors is not None:
                f.write('v {0} {1} {2} {3} {4} {5}\n'.format(points[i, 0], points[i, 1], points[i, 2], int(
                    colors[i, 0]), int(colors[i, 1]), int(colors[i, 2])))
            else:
                f.write('v {0} {1} {2}\n'.format(
                    points[i, 0], points[i, 1], points[i, 2]))


def mesh_to_correspondence(experiment_directory, checkpoint, start_id, end_id):

    specs_filename = os.path.join(experiment_directory, "specs.json")

    if not os.path.isfile(specs_filename):
        raise Exception(
            'The experiment directory does not include specifications file "specs.json"'
        )

    specs = json.load(open(specs_filename))

    num_samp_per_scene = None

    data_source = specs["DataSource"]

    train_split_file = specs["TrainSplit"]

    with open(train_split_file, "r") as f:
        train_split = json.load(f)

    instance_filenames = deep_sdf.data.get_instance_filenames(data_source, train_split)

    dataset = shapenet.ShapeNetDataset(
        data_source, train_split, num_samp_per_scene, load_ram=True
    )

    data_loader = data_utils.DataLoader(
        dataset,
        batch_size=1,
        shuffle=False,
    )

    for i, (xyz_data, indices) in enumerate(data_loader):
        print(indices[0])

        if i < start_id:
            continue

        if sys.platform.startswith('linux'):
            dataset_name, class_name, instance_name = os.path.normpath(instance_filenames[i]).split("/")
        else:
            dataset_name, class_name, instance_name = os.path.normpath(instance_filenames[i]).split("\\")
        # instance_name = instance_name.split(".")[0]
        instance_name = xyz_data[1][0]
        print('instance_name: ', instance_name)

        mesh_dir = '/raid/itaya/data/SurfaceSamples/ShapeNetV2/' + class_name

        if not os.path.isdir(mesh_dir):
            os.makedirs(mesh_dir)

        mesh_filename = os.path.join(mesh_dir, instance_name)
        print('mesh_filename: ', mesh_filename)

        queries = xyz_data[0].reshape(-1, 3).cuda()
        # store canonical coordinates as rgb color (in float format)
        # verts_color = 255 * (0.5 + 0.5 * queries.cpu().detach().numpy())
        # verts_color = verts_color.astype(np.uint8)
        # write_points_ply(mesh_filename + '_canonical_position_template_ori.ply', queries.cpu().detach().numpy(), rgb_points=verts_color)
        write_points_obj(mesh_filename + '.obj', queries.cpu().detach().numpy())

        if i >= end_id:
            break


if __name__ == "__main__":

    arg_parser = argparse.ArgumentParser(
        description="Use a trained DeepSDF decoder to generate a mesh given a latent code."
    )
    arg_parser.add_argument(
        "--experiment",
        "-e",
        dest="experiment_directory",
        required=True,
        help="The experiment directory which includes specifications and saved model "
        + "files to use for reconstruction",
    )
    arg_parser.add_argument(
        "--checkpoint",
        "-c",
        dest="checkpoint",
        default="latest",
        help="The checkpoint weights to use. This can be a number indicated an epoch "
        + "or 'latest' for the latest weights (this is the default)",
    )
    arg_parser.add_argument(
        "--start_id",
        dest="start_id",
        type=int,
        default=0,
        help="start_id.",
    )
    arg_parser.add_argument(
        "--end_id",
        dest="end_id",
        type=int,
        default=20,
        help="end_id.",
    )
    deep_sdf.add_common_args(arg_parser)

    args = arg_parser.parse_args()

    deep_sdf.configure_logging(args)

    mesh_to_correspondence(args.experiment_directory, args.checkpoint, args.start_id, args.end_id)
