# Inversed warping function of Deep Implicit Templates

CUDA=${1}

class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")

for name in ${class_name_list[@]};
do
  CUDA_VISIBLE_DEVICES=${CUDA} python train_inversed_function.py -e examples/${name}s_dit --debug --batch_split 4 -c latest -d /raid/itaya/data # --continue latest
done
