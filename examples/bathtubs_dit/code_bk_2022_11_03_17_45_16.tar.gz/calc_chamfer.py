"""
Calculation Chamfer distance for checking SMG results.
"""

import logging
import os
import sys

import argparse
import json
import numpy as np
import plyfile
import point_cloud_utils as pcu
import torch
import tqdm
import pytorch3d.loss

from chamferdist import ChamferDistance

from metrics.chamfer import ChamferDistance as CDLoss


synsetID2name = {
    '04379243': 'table',
    '03593526': 'jar',
    '04225987': 'skateboard',
    '02958343': 'car',
    '02876657': 'bottle',
    '04460130': 'tower',
    '03001627': 'chair',
    '02871439': 'bookshelf',
    '02942699': 'camera',
    '02691156': 'airplane',
    '03642806': 'laptop',
    '02801938': 'basket',
    '04256520': 'sofa',
    '03624134': 'knife',
    '02946921': 'can',
    '04090263': 'rifle',
    '04468005': 'train',
    '03938244': 'pillow',
    '03636649': 'lamp',
    '02747177': 'trash bin',
    '03710193': 'mailbox',
    '04530566': 'watercraft',
    '03790512': 'motorbike',
    '03207941': 'dishwasher',
    '02828884': 'bench',
    '03948459': 'pistol',
    '04099429': 'rocket',
    '03691459': 'loudspeaker',
    '03337140': 'file cabinet',
    '02773838': 'bag',
    '02933112': 'cabinet',
    '02818832': 'bed',
    '02843684': 'birdhouse',
    '03211117': 'display',
    '03928116': 'piano',
    '03261776': 'earphone',
    '04401088': 'telephone',
    '04330267': 'stove',
    '03759954': 'microphone',
    '02924116': 'bus',
    '03797390': 'mug',
    '04074963': 'remote',
    '02808440': 'bathtub',
    '02880940': 'bowl',
    '03085013': 'keyboard',
    '03467517': 'guitar',
    '04554684': 'washer',
    '02834778': 'bicycle',
    '03325088': 'faucet',
    '04004475': 'printer',
    '02954340': 'cap',
}

sdf_samples_subdir = "SdfSamples"
surface_samples_subdir = "SurfaceSamples"
normalization_param_subdir = "NormalizationParameters"
obj_samples_subdir = "ShapeNetCore.v2"


def get_instance_filenames(data_source, split):
    plyfiles = []
    npzfiles = []
    for dataset in split:
        for class_name in split[dataset]:
            for instance_name in split[dataset][class_name]:
                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".ply"
                )
                if not os.path.isfile(
                    os.path.join(data_source, surface_samples_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                plyfiles += [instance_filename]

                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".npz"
                )
                if not os.path.isfile(
                    os.path.join(data_source, normalization_param_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                npzfiles += [instance_filename]

    return plyfiles, npzfiles


def get_instance_filenames2(data_source, split):
    plyfiles = []
    npzfiles = []
    objfiles = []
    for dataset in split:
        for class_name in split[dataset]:
            for instance_name in split[dataset][class_name]:
                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".ply"
                )
                if not os.path.isfile(
                    os.path.join(data_source, surface_samples_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                plyfiles += [instance_filename]

                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".npz"
                )
                if not os.path.isfile(
                    os.path.join(data_source, normalization_param_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                npzfiles += [instance_filename]

                instance_filename = os.path.join(
                    class_name, "models", instance_name + ".obj"
                )
                if not os.path.isfile(
                    os.path.join(data_source, obj_samples_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                objfiles += [instance_filename]

    return plyfiles, npzfiles, objfiles


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


def read_ply_file(filename):
    plydata = plyfile.PlyData.read(filename)
    points = []  # plydata.elements[0]
    for i in range(plydata.elements[0].count):
        v = plydata.elements[0][i]
        points.append(np.array((v[0], v[1], v[2])))
    points = torch.from_numpy(np.asarray(points)).float()

    return points


class Shapes(torch.utils.data.Dataset):
    MESH_FILE_EXT = 'obj'
    POINT_CLOUD_FILE_EXT = 'pts'

    def __init__(self, data_source, data_list):

        # self.dataset = self.load_dataset()

        self.data_source = data_source
        # self.plyfiles, self.npyfiles = get_instance_filenames(data_source, data_list)
        self.plyfiles, self.npyfiles, self.objfiles = get_instance_filenames2(data_source, data_list)

        self.loaded_data = []
        error_list = []

        # for i, (ply_f, npz_f) in tqdm.tqdm(enumerate(zip(self.plyfiles, self.npyfiles)), ascii=True):
        for i, (ply_f, npz_f, obj_f) in enumerate(tqdm.tqdm(zip(self.plyfiles, self.npyfiles, self.objfiles), ascii=True)):

            if i == 10:
                break

            ply_filename = os.path.join(self.data_source, surface_samples_subdir, ply_f)
            points = read_ply_file(ply_filename)

            npz_filename = os.path.join(self.data_source, normalization_param_subdir, npz_f)
            npz = np.load(npz_filename)

            normalized_points = (points + npz['offset']) * npz['scale']

            obj_filename = os.path.join(self.data_source, obj_samples_subdir, obj_f)
            try:
                verts, faces, _ = pcu.read_obj(obj_filename, dtype=np.float32)
                verts = torch.from_numpy((verts + npz['offset']) * npz['scale'])
            except ValueError:
                error_list.append(obj_filename)
                continue

            print(normalized_points.shape, verts.shape)

            # self.loaded_data.append(
            #     [
            #         normalized_points,
            #         os.path.basename(ply_filename).split('.')[0],
            #     ]
            # )
            self.loaded_data.append(
                [
                    normalized_points,
                    verts,
                    os.path.basename(ply_filename).split('.')[0],
                ]
            )

        # load template GT
        # template_gt_dir = 'evaluation/templates_gt'
        # for dataset in data_list:
        #     for class_name in data_list[dataset]:
        #         template_gt_file = synsetID2name[class_name] + '.ply'

        # points = read_ply_file(template_gt_dir + '/' + template_gt_file)

        # self.loaded_data.append(
        #     [
        #         points,
        #         template_gt_file.split('.')[0],
        #     ]
        # )

        # self.loaded_data = sorted(self.loaded_data, lambda x: x[1])

        print("dataset size %d" % len(self))

    def __getitem__(self, index):
        try:
            return self.loaded_data[index]
        except Exception as e:
            warnings.warn(f"Error loading sample {index}: " + ''.join(
                traceback.format_exception(etype=type(e), value=e, tb=e.__traceback__)))
            import ipdb
            ipdb.set_trace()
            index += 1

    def __len__(self):
        return len(self.loaded_data)


def main_function(source_file_dir, target_file_dir, split_file):

    # source_file_list = [f for f in sorted(os.listdir(source_file_dir)) if f[-4:] == '.obj' or f[-4:] == '.ply']

    with open(split_file, "r") as f:
        target_list = json.load(f)

    dataset = Shapes(target_file_dir, target_list)

    dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size=1,
        shuffle=False,
    )

    output_dir = 'evaluation/chamfers'
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    # output_path = os.path.join(output_dir, os.path.basename(source_file_dir) + '2.json')

    # tmp
    class_name = split_file.split('/', 3)[2].split('_', 3)[1][:-1]
    print(class_name)
    output_path = "examples/{0}s_dit/TrainingMeshes/2000/{0}.json".format(class_name)

    json_data = {}

    # for i, source_file in tqdm.tqdm(enumerate(source_file_list)):
    # for i, data in tqdm.tqdm(enumerate(dataloader)):
    for i, data in enumerate(dataloader):

        # load target file
        # target_points, instance_name = data
        source_points, target_points, instance_name = data
        print(source_points.shape, target_points.shape)

        print(instance_name[0])

        # tmp
        write_points_ply("examples/{}s_dit/TrainingMeshes/2000/".format(class_name) + instance_name[0] + '_mesh_ori.ply', target_points.cpu().numpy()[0])
        write_points_ply("examples/{}s_dit/TrainingMeshes/2000/".format(class_name) + instance_name[0] + '_points_ori.ply', source_points.cpu().numpy()[0])

        # load source file
        #**** 提案手法評価時に使用 begin ****#
        # source_file_path = os.path.join(source_file_dir, instance_name[0] + '.ply')
        # source_points = read_ply_file(source_file_path).unsqueeze(0)
        #**** 提案手法評価時に使用 end ****#

        # source_points = source_points.repeat(2, 1, 1)
        # target_points = target_points.repeat(2, 1, 1)

        # print(source_points.shape, target_points.shape)

        # calculation chamfer distance
        # dist = 0.5 * ChamferDistance()(source_points, target_points, bidirectional=True)

        # dist1, dist2, _, _ = CDLoss()(
        #     source_points, target_points, bidirectional=True)
        # dist = dist1 + dist2

        dist = pytorch3d.loss.chamfer_distance(source_points.cuda(), target_points.cuda())[0]

        print("{}".format(dist.detach().cpu().item()))

        json_data[instance_name[0]] = dist.detach().cpu().item()

    # Serializing json
    json_object = json.dumps(json_data, indent=4)

    with open(output_path, 'w') as f:
        f.write(json_object)


if __name__ == "__main__":

    arg_parser = argparse.ArgumentParser(description="Train a DeepSDF autodecoder")
    arg_parser.add_argument(
        "--source_data",
        "-sd",
        dest="data_source",
        required=True,
        help="The data source directory.",
    )
    arg_parser.add_argument(
        "--target_data",
        "-td",
        dest="data_target",
        required=True,
        help="The data target directory.",
    )
    arg_parser.add_argument(
        "--split_file",
        "-s",
        dest="split_file",
        required=True,
        help="The split file of target data.",
    )

    args = arg_parser.parse_args()

    main_function(args.data_source, args.data_target, args.split_file)
