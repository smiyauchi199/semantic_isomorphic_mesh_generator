
# deepsdf

CUDA=${1}

# class_name_list=("airplane" "bathtub" "bed" "bottle" "bowl" "car" "chair" "display" "sofa" "table")
class_name_list=("bathtub" "bottle")
# class_name_list=("bathtub" "bottle" "car" "sofa")
# class_name_list=("display" "table")
# class_name_list=("knife" "pistol")

for name in ${class_name_list[@]}; 
do
  # DIT
  CUDA_VISIBLE_DEVICES=${CUDA} python train_deep_implicit_templates.py -e examples/${name}s_dit --debug --batch_split 1 -c latest -d /mnt/nas/3DModelDataset/ShapeNet
  # inv warper
  # CUDA_VISIBLE_DEVICES=${CUDA} python train_inversed_function.py -e examples/${name}s_dit --debug --batch_split 1 -c latest -d /mnt/nas/3DModelDataset/ShapeNet --continue latest
done

