import json
import random
import sys

import numpy as np


if __name__ == "__main__":

    args = sys.argv

    class_name = args[1]
    split_file = "splits/" + class_name + "2.json"

    with open(split_file, 'r') as f:
        split_data = json.load(f)

    for dataset_name in split_data.keys():
        for class_id in split_data[dataset_name].keys():
            model_list = split_data[dataset_name][class_id]

    num_sample = 62
    indices = sorted(random.sample(range(len(model_list)), k=num_sample))

    json_data = {dataset_name: {}}
    json_data[dataset_name][class_id] = list(np.asarray(model_list)[indices])
    json_object = json.dumps(json_data, indent=4)

    output_split_file = "splits/" + class_name + "_gcn.json"
    with open(output_split_file, 'w') as f:
        f.write(json_object)

