import json
import os
import sys

import h5py
import numpy as np
import plyfile
import point_cloud_utils as pcu

class_list = ["bathtub", "bottle", "car", "sofa"]


def read_from_ply(path):
    plydata = plyfile.PlyData.read(path)
    verts = []  # plydata.elements[0]
    faces = []  # plydata.elements[1]
    for i in range(plydata.elements[0].count):
        v = plydata.elements[0][i]
        verts.append(np.array((v[0], v[1], v[2])))
    for i in range(plydata.elements[1].count):
        f = plydata.elements[1][i]
        faces.append(np.array([f[0], f[1], f[2]]))
    verts = np.asarray(verts[:200000])
    faces = np.asarray(faces)
    
    return verts, faces


def write_to_hdf5(path, modelid_list, verts_list, label_list, A):
    hdf5_file = h5py.File(path, 'w')
    hdf5_file.create_dataset('modelID', [len(modelid_list), 1], h5py.string_dtype(length=32), compression='gzip')
    hdf5_file.create_dataset(
        "verts", [len(modelid_list), 2562, 3], np.float64, compression=9)
    hdf5_file.create_dataset(
        "label", [len(modelid_list), 1], np.int8, compression=9)
    hdf5_file.create_dataset(
        "A", [1, 2562, 2562], np.int8, compression=9)

    for idx, (modelID, verts, label) in enumerate(zip(modelid_list, verts_list, label_list)):
        hdf5_file['modelID'][idx] = modelID
        hdf5_file['verts'][idx] = verts
        hdf5_file['label'][idx] = label

    hdf5_file['A'][0] = A

    hdf5_file.close()


def adjacency_matrix(faces):
    A = np.zeros((2562, 2562))
    A[faces[:, 0], faces[:, 1]] = 1
    A[faces[:, 0], faces[:, 2]] = 1
    A[faces[:, 1], faces[:, 2]] = 1

    return A


if __name__ == "__main__":

    args = sys.argv
    method = args[1]

    output_dir = "gcn_data"

    all_instances = []
    all_verts = []
    all_labels = []

    for label, class_name in enumerate(class_list):

        split_file = "splits/" + class_name + "_gcn.json"
        with open(split_file, 'r') as f:
            split_data = json.load(f)

        for dataset_name in split_data.keys():
            for class_id in split_data[dataset_name].keys():
                instance_list = split_data[dataset_name][class_id]

        for idx, instance_name in enumerate(instance_list):
            # if idx == 1:
            #     break
            plyfile_path = os.path.join(class_name + "s_" + method, instance_name + ".ply")
            # verts, faces = read_from_ply(plyfile_path)
            verts, faces = pcu.load_mesh_vf(plyfile_path)
            all_instances.append(instance_name)
            all_verts.append(verts)
            all_labels.append(label)

            if label == 0 and idx == 0:
                A = adjacency_matrix(faces)

    output_path = os.path.join(output_dir, "four_classes_{}_dataset.hdf5".format(method))
    write_to_hdf5(output_path, all_instances, all_verts, all_labels, A)
