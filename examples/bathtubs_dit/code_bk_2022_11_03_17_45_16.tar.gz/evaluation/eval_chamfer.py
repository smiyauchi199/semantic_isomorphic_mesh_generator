import json
import os
import sys


if __name__ == "__main__":

    args = sys.argv

    input_file = args[1]

    with open(input_file, 'r') as f:
        chamfer_data = json.load(f)


    sum_of_chamfer = 0.0
    cnt = 0

    for k, v in chamfer_data.items():
        cnt += 1
        sum_of_chamfer += v

    print(sum_of_chamfer / cnt)
