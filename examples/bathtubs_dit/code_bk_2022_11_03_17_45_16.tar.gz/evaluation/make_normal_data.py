import os
import sys

import numpy as np
import plyfile
import point_cloud_utils as pcu


def write_points_obj(fname, points, colors=None, points_normals=None):

        with open(fname, 'w') as f:

            num = points.shape[0]
            for i in range(0, num):
                if colors is not None:
                    f.write('v {0} {1} {2} {3} {4} {5}\n'.format(points[i, 0], points[i, 1], points[i, 2], int(colors[i, 0]), int(colors[i, 1]), int(colors[i, 2])))
                else:
                    f.write('v {0} {1} {2}\n'.format(points[i, 0], points[i, 1], points[i, 2]))

            for i in range(0, num):
                f.write('vn {0} {1} {2}\n'.format(points_normals[i, 0], points_normals[i, 1], points_normals[i, 2]))


def write_to_ply(filename, xyz_points, faces=None, verts_normals=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    if verts_normals is not None:
        fout.write("property float nx\n")
        fout.write("property float ny\n")
        fout.write("property float nz\n")

    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")

    if verts_normals is not None:
        for i in range(xyz_points.shape[0]):
            color = rgb_points[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
                xyz_points[i, 2]) + " " + str(verts_normals[i, 0]) + " " + str(
                    verts_normals[i, 1]) + " " + str(verts_normals[i, 2]) + " " + color + "\n")
    else:
        for i in range(xyz_points.shape[0]):
            color = rgb_points[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
                xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


def read_from_ply(path):
    plydata = plyfile.PlyData.read(path)
    verts = []  # plydata.elements[0]
    faces = []  # plydata.elements[1]
    for i in range(plydata.elements[0].count):
        v = plydata.elements[0][i]
        verts.append(np.array((v[0], v[1], v[2])))
    for i in range(plydata.elements[1].count):
        f = plydata.elements[1][i]
        faces.append(np.array([f[0], f[1], f[2]]))
    verts = np.asarray(verts)
    faces = np.asarray(faces)
    
    return verts, faces


if __name__ == "__main__":

    args = sys.argv

    input_dir = args[1]
    input_file_list = os.listdir(input_dir)
    print(len(input_file_list))

    output_dir = input_dir.split('_')[1] + "_normals"
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    for idx, input_file in enumerate(input_file_list):
        if idx == 5:
            break

        verts, faces = read_from_ply(input_dir + '/' + input_file)
        verts_normals = pcu.estimate_normals(verts, k=16)
        print(verts[0], verts_normals[0])
        # output_path = input_file.split('.')[0] + "_normals.ply"
        # write_to_ply(output_path, verts, verts_normals=verts_normals)
        output_data = np.concatenate([verts, verts_normals], axis=1)
        print(output_data[0])
        print(output_data.shape)
        output_path = output_dir + '/' + input_file.split('.')[0]
        np.save(output_path, output_data)
