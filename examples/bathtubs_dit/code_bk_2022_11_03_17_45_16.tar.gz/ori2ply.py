import logging
import os
import sys

import numpy as np
import plyfile
import point_cloud_utils as pcu
import tqdm


def read_line(line):
    line = line.rstrip().split(' ')

    return np.asarray(line[0]), np.asarray(line[1]), np.asarray(line[2])


def read_ori_file(input_file):

    with open(input_file, 'r') as f:

        num_vtx = f.readline()

        vertices = []
        for i in range(int(num_vtx)):
            line = f.readline()
            line = read_line(line)
            vertices.append(line)
        vertices = np.asarray(vertices)

        num_faces = f.readline()

        faces = []
        normals = []
        for i in range(int(num_faces)):
            line = f.readline()
            line = read_line(line)
            faces.append(line)

            line = f.readline()
            line = read_line(line)
            normals.append(line)

            f.readline()  # ???

        faces = np.asarray(faces)
        normals = np.asarray(normals)

    return vertices, faces, normals


def write_ply_file(output_file, verts, faces=None):
    # try writing to the ply file

    num_verts = verts.shape[0]
    if faces is not None:
        num_faces = faces.shape[0]

    verts_tuple = np.zeros((num_verts,), dtype=[("x", "f4"), ("y", "f4"), ("z", "f4")])

    for i in range(0, num_verts):
        verts_tuple[i] = tuple(verts[i, :])
    el_verts = plyfile.PlyElement.describe(verts_tuple, "vertex")

    if faces is not None:
        faces_building = []
        for i in range(0, num_faces):
            faces_building.append(((faces[i, :].tolist(),)))
        faces_tuple = np.array(faces_building, dtype=[("vertex_indices", "i4", (3,))])
        el_faces = plyfile.PlyElement.describe(faces_tuple, "face")
        ply_data = plyfile.PlyData([el_verts, el_faces])
    else:
        ply_data = plyfile.PlyData([el_verts])

    logging.debug("saving mesh to %s" % (output_file))
    ply_data.write(output_file)


if __name__ == '__main__':

    args = sys.argv

    input_dir = args[1]
    input_files = [f for f in sorted(os.listdir(input_dir)) if f[-4:] == '.ori']
    output_dir = os.path.dirname(input_dir)

    exts = '.ply'

    for input_file in tqdm.tqdm(input_files):
        print(input_file)
        v, f, n = read_ori_file(input_dir + '/' + input_file)
        print(v.shape)
        print(f.shape)
        write_ply_file(output_dir + '/' + os.path.basename(input_file)[:-4] + exts, v, faces=f)

