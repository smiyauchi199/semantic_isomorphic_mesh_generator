import os
import sys

import json


synsetid2name = {
        '02691156': 'airplane',
        '02808440': 'bathtub',
        '02818832': 'bed',
        # '02828884': 'bench',
        '02876657': 'bottle',
        '02880940': 'bowl',
        '02958343': 'car',
        '03001627': 'chair',
        '03211117': 'display',
        '04256520': 'sofa',
        '04379243': 'table',
        }


if __name__ == '__main__':

    # args = sys.argv
    # id = args[1]

    for key, value in synsetid2name.items():
        id = key

        if id == '02808440':

            dataset_name = 'ShapeNetV2'

            # input_dir = '/media/user/itaya/data/ShapeNetCore.v2/' + id
            # output_path = 'examples/splits/' + 'sv2_{}s_all.json'.format(synsetid2name[id])
            input_dir = 'evaluation/bathtubs_pixel2mesh'
            output_path = 'evaluation/splits/bathtub_ori.json'

            # instance_name_list = sorted(os.listdir(input_dir))
            instance_name_list = sorted([f[:-4] for f in os.listdir(input_dir)])
            try:
                instance_name_list.remove('models')
            except:
                pass

            json_data = {dataset_name: {}}
            # json_data[dataset_name][id] = instance_name_list
            json_data[dataset_name][id] = instance_name_list

            # Serializing json
            json_object = json.dumps(json_data, indent=4)

            with open(output_path, 'w') as f:
                f.write(json_object)
