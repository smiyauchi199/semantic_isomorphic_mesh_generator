""" uniformly sample points from meshes
"""

import logging
import os
import sys

import numpy as np
import open3d as o3d
import plyfile
from open3d import geometry
# from pytorch3d.io import load_obj
# from pytorch3d.ops import sample_points_from_meshes


def write_ply_file(output_file, verts, faces=None):
    # try writing to the ply file

    num_verts = verts.shape[0]
    if faces is not None:
        num_faces = faces.shape[0]

    verts_tuple = np.zeros((num_verts,), dtype=[("x", "f4"), ("y", "f4"), ("z", "f4")])

    for i in range(0, num_verts):
        verts_tuple[i] = tuple(verts[i, :])
    el_verts = plyfile.PlyElement.describe(verts_tuple, "vertex")

    if faces is not None:
        faces_building = []
        for i in range(0, num_faces):
            faces_building.append(((faces[i, :].tolist(),)))
        faces_tuple = np.array(faces_building, dtype=[("vertex_indices", "i4", (3,))])
        el_faces = plyfile.PlyElement.describe(faces_tuple, "face")
        ply_data = plyfile.PlyData([el_verts, el_faces])

    ply_data = plyfile.PlyData([el_verts])
    logging.debug("saving mesh to %s" % (output_file))
    ply_data.write(output_file)


if __name__ == "__main__":
    args = sys.argv

    input_path = args[1]
    output_path = os.path.dirname(input_path)

    mesh = o3d.io.read_triangle_mesh(input_path)
    print(mesh)
    sampled_points = geometry.TriangleMesh.sample_points_uniformly(mesh, number_of_points=10000-2562)
    print(sampled_points)

    final_points = np.concatenate([np.asarray(mesh.vertices), np.asarray(sampled_points.points)])
    print(final_points.shape)

    write_ply_file(output_path + '/template_smg_sampled.ply', final_points)

