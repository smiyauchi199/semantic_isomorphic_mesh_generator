
CUDA=${1}

class_name_list=("airplane")
# class_name_list=("bathtub")
# class_name_list=("bottle")
# class_name_list=("chair")
# class_name_list=("knife" "pistol" "sofa")
# class_name_list=("car")
# class_name_list=("bathtub" "bottle" "car" "pistol" "sofa")

for name in ${class_name_list[@]};
do
  CUDA_VISIBLE_DEVICES=${CUDA} python generate_structured_meshes.py -e examples/${name}s_dit --debug --start_id 0 --end_id 4 --batch_split 1
done
