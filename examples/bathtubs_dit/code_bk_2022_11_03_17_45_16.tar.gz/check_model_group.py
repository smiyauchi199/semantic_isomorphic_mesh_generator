"""
Calculation Chamfer distance for checking SMG results.
"""

import logging
import os
import sys

import argparse
import json
import numpy as np
import plyfile
import point_cloud_utils as pcu
import torch
import tqdm
# import pytorch3d.loss

from chamferdist import ChamferDistance

from metrics.chamfer import ChamferDistance as CDLoss


synsetID2name = {
    '04379243': 'table',
    '03593526': 'jar',
    '04225987': 'skateboard',
    '02958343': 'car',
    '02876657': 'bottle',
    '04460130': 'tower',
    '03001627': 'chair',
    '02871439': 'bookshelf',
    '02942699': 'camera',
    '02691156': 'airplane',
    '03642806': 'laptop',
    '02801938': 'basket',
    '04256520': 'sofa',
    '03624134': 'knife',
    '02946921': 'can',
    '04090263': 'rifle',
    '04468005': 'train',
    '03938244': 'pillow',
    '03636649': 'lamp',
    '02747177': 'trash bin',
    '03710193': 'mailbox',
    '04530566': 'watercraft',
    '03790512': 'motorbike',
    '03207941': 'dishwasher',
    '02828884': 'bench',
    '03948459': 'pistol',
    '04099429': 'rocket',
    '03691459': 'loudspeaker',
    '03337140': 'file cabinet',
    '02773838': 'bag',
    '02933112': 'cabinet',
    '02818832': 'bed',
    '02843684': 'birdhouse',
    '03211117': 'display',
    '03928116': 'piano',
    '03261776': 'earphone',
    '04401088': 'telephone',
    '04330267': 'stove',
    '03759954': 'microphone',
    '02924116': 'bus',
    '03797390': 'mug',
    '04074963': 'remote',
    '02808440': 'bathtub',
    '02880940': 'bowl',
    '03085013': 'keyboard',
    '03467517': 'guitar',
    '04554684': 'washer',
    '02834778': 'bicycle',
    '03325088': 'faucet',
    '04004475': 'printer',
    '02954340': 'cap',
}


def get_instance_filenames(data_source, split):
    plyfiles = []
    npzfiles = []
    for dataset in split:
        for class_name in split[dataset]:
            for instance_name in split[dataset][class_name]:
                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".ply"
                )
                if not os.path.isfile(
                    os.path.join(data_source, surface_samples_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                plyfiles += [instance_filename]

                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".npz"
                )
                if not os.path.isfile(
                    os.path.join(data_source, normalization_param_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                npzfiles += [instance_filename]

    return plyfiles, npzfiles


def main_function(source_file_dir, target_file_dir, split_file):

    # source_file_list = [f for f in sorted(os.listdir(source_file_dir)) if f[-4:] == '.obj' or f[-4:] == '.ply']

    with open(split_file, "r") as f:
        target_list = json.load(f)

    instance_list = []
    for dataset in target_list:
        for class_name in target_list[dataset]:
            for instance_name in target_list[dataset][class_name]:
                # print(instance_name)
                instance_list.append(instance_name)

    filepath = '/Users/itayakyo/Downloads/structured_meshes/{}s.txt'.format(synsetID2name[class_name])
    with open(filepath, 'r') as f:
        file_data = f.readlines()
    check_list = []
    for line in file_data:
        line = line.rstrip()
        if line in instance_list:
            # print(line)
            check_list.append(line)

    print(len(check_list))

    for key, value in synsetID2name.items():
        id = key

        if id == class_name:

            dataset_name = 'ShapeNetV2'

            output_path = 'evaluation/splits/{}2.json'.format(synsetID2name[id])

            instance_name_list = check_list
            try:
                instance_name_list.remove('models')
            except:
                pass

            json_data = {dataset_name: {}}
            json_data[dataset_name][id] = instance_name_list

            # Serializing json
            json_object = json.dumps(json_data, indent=4)

            with open(output_path, 'w') as f:
                f.write(json_object)


if __name__ == "__main__":

    arg_parser = argparse.ArgumentParser(description="Train a DeepSDF autodecoder")
    arg_parser.add_argument(
        "--source_data",
        "-sd",
        dest="data_source",
        required=True,
        help="The data source directory.",
    )
    arg_parser.add_argument(
        "--target_data",
        "-td",
        dest="data_target",
        required=True,
        help="The data target directory.",
    )
    arg_parser.add_argument(
        "--split_file",
        "-s",
        dest="split_file",
        required=True,
        help="The split file of target data.",
    )

    args = arg_parser.parse_args()

    main_function(args.data_source, args.data_target, args.split_file)
