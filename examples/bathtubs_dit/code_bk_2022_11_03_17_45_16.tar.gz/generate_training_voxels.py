#!/usr/bin/env python3
# Copyright 2004-present Facebook. All Rights Reserved.

import argparse
import h5py
import json
import numpy as np
import os
import torch
import torch.nn.functional as F
import torch.utils.data as data_utils
import sys
import deep_sdf
import deep_sdf.workspace as ws


def sample_outer_surface_in_voxel(volume):
    # inner surface
    # a = F.max_pool3d(-volume[None,None].float(), kernel_size=(3,1,1), stride=1, padding=(1, 0, 0))[0]
    # b = F.max_pool3d(-volume[None,None].float(), kernel_size=(1,3, 1), stride=1, padding=(0, 1, 0))[0]
    # c = F.max_pool3d(-volume[None,None].float(), kernel_size=(1,1,3), stride=1, padding=(0, 0, 1))[0]
    # border, _ = torch.max(torch.cat([a,b,c],dim=0),dim=0)
    # surface = border + volume.float()

    # outer surface
    a = F.max_pool3d(volume[None, None].float().cuda(), kernel_size=(
        3, 1, 1), stride=1, padding=(1, 0, 0))[0]
    b = F.max_pool3d(volume[None, None].float().cuda(), kernel_size=(
        1, 3, 1), stride=1, padding=(0, 1, 0))[0]
    c = F.max_pool3d(volume[None, None].float().cuda(), kernel_size=(
        1, 1, 3), stride=1, padding=(0, 0, 1))[0]
    border, _ = torch.max(torch.cat([a, b, c], dim=0), dim=0)
    surface = border - volume.float().cuda()
    return surface.long()


def normalize_vertices(vertices, shape):
    assert len(vertices.shape) == 2 and len(
        shape.shape) == 2, "Inputs must be 2 dim"
    assert shape.shape[0] == 1, "first dim of shape should be length 1"

    return 2 * (vertices / (torch.max(shape) - 1) - 0.5)


def gather_voxels(sdf_list, hdf5_dir, class_name, modelIDs):

    voxel_dim = 64
    # voxel_dim = 256
    sample_num = 3000
    hdf5_path = os.path.join(
        # hdf5_dir, "{}_{}.hdf5".format(class_name, voxel_dim))
        hdf5_dir, "{}_{}_new.hdf5".format(class_name, voxel_dim))
    print('hdf5_path: ', hdf5_path)

    hdf5_file = h5py.File(hdf5_path, 'w')
    hdf5_file.create_dataset(
        "voxels", [len(sdf_list), voxel_dim, voxel_dim, voxel_dim], np.float64, compression=9)
    hdf5_file.create_dataset(
        "labels", [len(sdf_list), voxel_dim, voxel_dim, voxel_dim], np.float64, compression=9)
    # hdf5_file.create_dataset(
    #     "surface_points", [len(sdf_list), sample_num, 3], np.float64, compression=9)
    hdf5_file.create_dataset('modelID', [len(sdf_list)], h5py.string_dtype(length=32), compression='gzip')

    for idx, sdf_values in enumerate(sdf_list):
        print(idx)

        indices = np.where(sdf_values <= 0.0)

        voxels = torch.zeros(voxel_dim, voxel_dim, voxel_dim, 1).float()
        labels = torch.zeros(voxel_dim, voxel_dim, voxel_dim, 1).float()
        voxels[indices[0], indices[1], indices[2], 0] = 1.0
        labels[indices[0], indices[1], indices[2], 0] = 1.0
        voxels = voxels.squeeze(-1)
        labels = labels.squeeze(-1)

        hdf5_file['voxels'][idx] = voxels
        hdf5_file['labels'][idx] = labels

        # shape = torch.tensor(labels.shape)[None].float().cuda()
        # y_outer = sample_outer_surface_in_voxel((labels == 1.0).long().cuda())
        # surface_points = torch.nonzero(y_outer).cuda()
        # # convert z,y,x -> x, y, z
        # # surface_points = torch.flip(surface_points, dims=[1]).float()
        # surface_points_normalized = normalize_vertices(
        #     surface_points, shape).cpu()

        # perm = torch.randperm(len(surface_points_normalized))
        # # randomly pick 3000 points
        # hdf5_file["surface_points"][idx] = surface_points_normalized[perm[:np.min(
        #     [len(perm), sample_num])]]

        hdf5_file['modelID'][idx] = modelIDs[idx]

    hdf5_file.close()
    print("finished")


def code_to_mesh(experiment_directory, checkpoint, start_id, end_id,
                 keep_normalized=False, use_octree=True, resolution=256):

    specs_filename = os.path.join(experiment_directory, "specs.json")

    if not os.path.isfile(specs_filename):
        raise Exception(
            'The experiment directory does not include specifications file "specs.json"'
        )

    specs = json.load(open(specs_filename))

    arch = __import__("networks." + specs["NetworkArch"], fromlist=["Decoder"])

    latent_size = specs["CodeLength"]

    decoder = arch.Decoder(latent_size, **specs["NetworkSpecs"])

    decoder = torch.nn.DataParallel(decoder)

    saved_model_state = torch.load(
        os.path.join(experiment_directory,
                     ws.model_params_subdir, checkpoint + ".pth")
    )
    saved_model_epoch = saved_model_state["epoch"]

    decoder.load_state_dict(saved_model_state["model_state_dict"])

    decoder = decoder.module.cuda()

    decoder.eval()

    clamping_function = None
    if specs["NetworkArch"] == "deep_sdf_decoder":
        def clamping_function(x): return torch.clamp(
            x, -specs["ClampingDistance"], specs["ClampingDistance"])
    elif specs["NetworkArch"] == "deep_implicit_template_decoder":
        def clamping_function(x): return torch.clamp(
            x, -specs["ClampingDistance"], specs["ClampingDistance"])

    latent_vectors = ws.load_pre_trained_latent_vectors(
        experiment_directory, checkpoint)
    latent_vectors = latent_vectors.cuda()

    train_split_file = specs["TrainSplit"]

    with open(train_split_file, "r") as f:
        train_split = json.load(f)

    data_source = specs["DataSource"]

    instance_filenames = deep_sdf.data.get_instance_filenames(
        data_source, train_split)

    print(len(instance_filenames), " vs ", len(latent_vectors))

    num_samp_per_scene = None

    sdf_dataset = deep_sdf.data.SDFSamples(
        data_source, train_split, num_samp_per_scene, load_ram=False
    )

    sdf_loader = data_utils.DataLoader(
        sdf_dataset,
        batch_size=1,
        shuffle=False,
        drop_last=True,
    )

    sdf_list = []
    modelIDs = []

    for i, (sdf_data, indices) in enumerate(sdf_loader):
        if i < start_id:
            continue

        # Process the input data
        sdf_data = torch.cat([sdf_data['pos'], sdf_data['neg']], 1)
        sdf_data = sdf_data.reshape(-1, 4).cuda()

        sdf_data.requires_grad = False

        latent_vector = latent_vectors[i]

        print(os.path.normpath(instance_filenames[i]))
        if sys.platform.startswith('linux'):
            dataset_name, class_name, instance_name = os.path.normpath(
                instance_filenames[i]).split("/")
        else:
            dataset_name, class_name, instance_name = os.path.normpath(
                instance_filenames[i]).split("\\")
        instance_name = instance_name.split(".")[0]
        modelIDs.append(instance_name)

        mesh_dir = os.path.join(
            experiment_directory,
            ws.training_meshes_subdir,
            str(saved_model_epoch),
            "voxels",
            class_name,
        )

        if not os.path.isdir(mesh_dir):
            os.makedirs(mesh_dir)

        mesh_filename = os.path.join(mesh_dir, instance_name)

        offset = None
        scale = None

        if not keep_normalized:

            normalization_params = np.load(
                ws.get_normalization_params_filename(
                    data_source, dataset_name, class_name, instance_name
                )
            )
            offset = normalization_params["offset"]
            scale = normalization_params["scale"]

        if use_octree:
            with torch.no_grad():
                sdf_values = deep_sdf.mesh.create_mesh_octree(
                    decoder,
                    latent_vector,
                    mesh_filename,
                    # N=resolution,
                    N=64,
                    max_batch=int(2 ** 17),
                    offset=offset,
                    scale=scale,
                    clamp_func=clamping_function,
                    save_voxel=True,
                    sdf_data=sdf_data,
                    # sdf_data=None,
                )
                sdf_list.append(sdf_values)
        else:
            with torch.no_grad():
                sdf_values = deep_sdf.mesh.create_mesh(
                    decoder,
                    latent_vector,
                    mesh_filename,
                    # N=resolution,
                    N=64,
                    max_batch=int(2 ** 17),
                    offset=offset,
                    scale=scale,
                    save_voxel=True,
                    sdf_data=sdf_data
                )
                sdf_list.append(sdf_values)

        if i >= end_id:
            break

        del sdf_data

    gather_voxels(sdf_list, mesh_dir, class_name, modelIDs)


if __name__ == "__main__":

    arg_parser = argparse.ArgumentParser(
        description="Use a trained DeepSDF decoder to generate a mesh given a latent code."
    )
    arg_parser.add_argument(
        "--experiment",
        "-e",
        dest="experiment_directory",
        required=True,
        help="The experiment directory which includes specifications and saved model "
        + "files to use for reconstruction",
    )
    arg_parser.add_argument(
        "--checkpoint",
        "-c",
        dest="checkpoint",
        default="latest",
        help="The checkpoint weights to use. This can be a number indicated an epoch "
        + "or 'latest' for the latest weights (this is the default)",
    )
    arg_parser.add_argument(
        "--keep_normalization",
        dest="keep_normalized",
        default=False,
        action="store_true",
        help="If set, keep the meshes in the normalized scale.",
    )
    arg_parser.add_argument(
        "--start_id",
        dest="start_id",
        type=int,
        default=0,
        help="start_id.",
    )
    arg_parser.add_argument(
        "--end_id",
        dest="end_id",
        type=int,
        default=20,
        help="end_id.",
    )
    arg_parser.add_argument(
        "--resolution",
        dest="resolution",
        type=int,
        default=256,
        help="Marching cube resolution.",
    )

    use_octree_group = arg_parser.add_mutually_exclusive_group()
    use_octree_group.add_argument(
        '--octree',
        dest='use_octree',
        action='store_true',
        help='Use octree to accelerate inference. Octree is recommend for most object categories '
             'except those with thin structures like planes'
    )
    use_octree_group.add_argument(
        '--no_octree',
        dest='use_octree',
        action='store_false',
        help='Don\'t use octree to accelerate inference. Octree is recommend for most object categories '
             'except those with thin structures like planes'
    )

    deep_sdf.add_common_args(arg_parser)

    args = arg_parser.parse_args()

    deep_sdf.configure_logging(args)

    code_to_mesh(
        args.experiment_directory,
        args.checkpoint,
        args.start_id,
        args.end_id,
        args.keep_normalized,
        args.use_octree,
        args.resolution)

# def code_to_mesh(experiment_directory, checkpoint):
# 
#     specs_filename = os.path.join(experiment_directory, "specs.json")
# 
#     if not os.path.isfile(specs_filename):
#         raise Exception(
#             'The experiment directory does not include specifications file "specs.json"'
#         )
# 
#     specs = json.load(open(specs_filename))
# 
#     arch = __import__("networks." + specs["NetworkArch"], fromlist=["Decoder"])
# 
#     latent_size = specs["CodeLength"]
# 
#     decoder = arch.Decoder(latent_size, **specs["NetworkSpecs"])
#     decoder = torch.nn.DataParallel(decoder)
# 
#     saved_model_state = torch.load(
#         os.path.join(experiment_directory, ws.model_params_subdir, checkpoint + ".pth")
#     )
#     saved_model_epoch = saved_model_state["epoch"]
# 
#     decoder.load_state_dict(saved_model_state["model_state_dict"])
# 
#     decoder = decoder.module.cuda()
# 
#     decoder.eval()
# 
#     mesh_dir = os.path.join(
#         experiment_directory,
#         ws.training_meshes_subdir,
#         str(saved_model_epoch),
#     )
# 
#     class_name = os.path.basename(experiment_directory)[:-4]
#     print(class_name)
#     modelIDs = [class_name]
# 
#     if not os.path.isdir(mesh_dir):
#         os.makedirs(mesh_dir)
# 
#     mesh_filename = os.path.join(mesh_dir, 'template')
# 
#     print(mesh_filename)
#     offset = None
#     scale = None
# 
#     sdf_list = []
#     with torch.no_grad():
#         sdf_values = deep_sdf.mesh.create_mesh(
#                          decoder.forward_template,
#                          None,
#                          mesh_filename,
#                          # N=512,
#                          N=64,
#                          max_batch=int(2 ** 20),
#                          offset=offset,
#                          scale=scale,
#                          volume_size=2.0,
#                          save_voxel=True
#                      )
#         sdf_list.append(sdf_values)
# 
#     gather_voxels(sdf_list, mesh_dir, class_name, modelIDs)
# 
# 
# if __name__ == "__main__":
# 
#     arg_parser = argparse.ArgumentParser(
#         description="Use a trained DeepSDF decoder to generate a mesh given a latent code."
#     )
#     arg_parser.add_argument(
#         "--experiment",
#         "-e",
#         dest="experiment_directory",
#         required=True,
#         help="The experiment directory which includes specifications and saved model "
#         + "files to use for reconstruction",
#     )
#     arg_parser.add_argument(
#         "--checkpoint",
#         "-c",
#         dest="checkpoint",
#         default="latest",
#         help="The checkpoint weights to use. This can be a number indicated an epoch "
#         + "or 'latest' for the latest weights (this is the default)",
#     )
#     deep_sdf.add_common_args(arg_parser)
# 
#     args = arg_parser.parse_args()
# 
#     deep_sdf.configure_logging(args)
# 
#     code_to_mesh(args.experiment_directory, args.checkpoint)
