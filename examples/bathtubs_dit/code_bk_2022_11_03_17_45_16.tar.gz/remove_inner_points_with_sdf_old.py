#!/usr/bin/env python3
# Copyright 2004-present Facebook. All Rights Reserved.

import json
import logging
import os
import sys

import argparse
import h5py
import numpy as np
import plyfile
import torch
import tqdm

import deep_sdf
import deep_sdf.workspace as ws
import shapenet_rminner
import torch.utils.data as data_utils
from pytorch3d.ops import sample_points_from_meshes
from pytorch3d.structures import Meshes

from pointnet2_utils import farthest_point_sample, index_points


obj_samples_subdir = "ShapeNetCore.v2"


def write_points_obj(fname, points, colors=None):

    with open(fname, 'w') as f:

        num = points.shape[0]
        for i in range(0, num):
            if colors is not None:
                f.write('v {0} {1} {2} {3} {4} {5}\n'.format(points[i, 0], points[i, 1], points[i, 2], int(colors[i, 0]), int(colors[i, 1]), int(colors[i, 2])))
            else:
                f.write('v {0} {1} {2}\n'.format(points[i, 0], points[i, 1], points[i, 2]))


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


def save_to_ply(ply_filename_out, verts, verts_warped=None, faces=None):
    num_verts = verts.shape[0]
    if faces is not None:
        num_faces = faces.shape[0]

    if verts_warped is not None:
        # store canonical coordinates as rgb color (in float format)
        verts_color = 255 * (0.5 + 0.5 * verts_warped)
        verts_color = verts_color.astype(np.uint8)

        verts_tuple = np.zeros(
            (num_verts,), dtype=[("x", "f4"), ("y", "f4"), ("z", "f4"), ("red", "f4"), ("green", "f4"), ("blue", "f4")])

        for i in range(0, num_verts):
            verts_tuple[i] = (verts[i][0], verts[i][1], verts[i][2],
                              verts_color[i][0], verts_color[i][1], verts_color[i][2])
    else:
        verts_tuple = np.zeros(
            (num_verts,), dtype=[("x", "f4"), ("y", "f4"), ("z", "f4")])

        for i in range(0, num_verts):
            verts_tuple[i] = (verts[i][0], verts[i][1], verts[i][2])

    el_verts = plyfile.PlyElement.describe(verts_tuple, "vertex")

    if faces is not None:
        faces_building = []
        for i in range(0, num_faces):
            faces_building.append(((faces[i, :].tolist(),)))
        faces_tuple = np.array(faces_building, dtype=[("vertex_indices", "i4", (3,))])

        el_faces = plyfile.PlyElement.describe(faces_tuple, "face")

    if faces is not None:
        ply_data = plyfile.PlyData([el_verts, el_faces])
    else:
        ply_data = plyfile.PlyData([el_verts])

    logging.debug("saving mesh to %s" % (ply_filename_out))
    ply_data.write(ply_filename_out)


def write_to_hdf5(path, model_id, verts, tris=None):

    hdf5_path = os.path.join(
        path, "{}.hdf5".format(model_id))
    print('hdf5_path: ', hdf5_path)

    hdf5_file = h5py.File(hdf5_path, 'w')
    hdf5_file.create_dataset(
        "verts", [1, len(verts), 3], np.float64, compression=9)
    if tris is not None:
        hdf5_file.create_dataset(
            "tris", [1, len(tris), 3], np.float64, compression=9)
    hdf5_file.create_dataset('modelID', [1], h5py.string_dtype(length=32), compression='gzip')

    hdf5_file['verts'][0] = verts
    if tris is not None:
        hdf5_file['tris'][0] = tris
    hdf5_file['modelID'][0] = model_id

    hdf5_file.close()


def validate_inner_or_outer(source_points, positive, negative):
    """
    inner is True, outer is False.
    """
    sdf_data = torch.cat([positive[0], negative[0]], 0)
    sdf_data = sdf_data.reshape(-1, 4)
    xyz = sdf_data[:, :3]
    sdf = sdf_data[:, 3]

    batch_split = 2
    xyz_ = torch.chunk(torch.Tensor(xyz), batch_split)
    sdf_ = torch.chunk(torch.Tensor(sdf), batch_split)
    source_points = torch.Tensor(source_points)
    begin_idx = 0
    nn_points = []
    nn_sdfs = []
    for i in range(batch_split):
        # if i == 2:
        #     break
        print(i)
        dist = torch.cdist(source_points.cuda(), xyz_[i].cuda(), p=2).cpu()
        indices = dist.topk(10, largest=False).indices.flatten().unique()
        nn_points.append(xyz_[i][indices])
        nn_sdfs.append(sdf_[i][indices])
        del dist
        begin_idx += xyz_[i].shape[0]

    nn_points = torch.cat(nn_points, 0).numpy()
    nn_sdfs = torch.cat(nn_sdfs, 0).numpy()

    # output_file = input_file.split('.')[0] + "_nn_points.ply"
    # write_to_ply(output_file, nn_points)
    dist = torch.cdist(source_points.cuda(), torch.Tensor(nn_points).cuda(), p=2).cpu()
    indices = dist.topk(5, largest=False).indices
    # output_file = input_file.split('.')[0] + "_5nn_points.ply"
    # write_to_ply(output_file, nn_points[indices].reshape(-1, 3))

    nn_sdf = torch.Tensor(nn_sdfs[indices])
    nn_sdf = torch.where(nn_sdf > 0, 1, 0).sum(dim=1)
    inner_indices = torch.where(nn_sdf > 0, False, True).numpy()
    outer_indices = torch.where(nn_sdf > 0, True, False).numpy()
    inner_points = source_points[inner_indices]
    outer_points = source_points[outer_indices]
    # output_file = input_file.split('.')[0] + "_inner_points.ply"
    # write_to_ply(output_file, inner_points)
    # output_file = input_file.split('.')[0] + "_outer_points.ply"
    # write_to_ply(output_file, outer_points)

    return outer_points


def mesh_to_correspondence(experiment_directory, checkpoint, start_id, end_id):

    specs_filename = os.path.join(experiment_directory, "specs.json")

    if not os.path.isfile(specs_filename):
        raise Exception(
            'The experiment directory does not include specifications file "specs.json"'
        )

    specs = json.load(open(specs_filename))

    # arch = __import__("networks." + specs["NetworkArch"], fromlist=["Decoder"])

    # latent_size = specs["CodeLength"]

    # decoder = arch.Decoder(latent_size, **specs["NetworkSpecs"])
    # decoder = torch.nn.DataParallel(decoder)
    saved_model_state = torch.load(
        os.path.join(experiment_directory, ws.model_params_subdir, checkpoint + ".pth")
    )
    saved_model_epoch = saved_model_state["epoch"]
    # decoder.load_state_dict(saved_model_state["model_state_dict"])
    # decoder = decoder.module.cuda()
    # decoder.eval()

    # num_samp_per_scene = specs["SamplesPerScene"]
    num_samp_per_scene = None
    data_source = specs["DataSource"]
    train_split_file = specs["TrainSplit"]
    with open(train_split_file, "r") as f:
        train_split = json.load(f)

    train_dataset = shapenet_rminner.ShapeNetDataset(
        data_source, train_split, num_samp_per_scene, load_ram=True
    )

    class_name = train_split_file.split('_', 3)[1][:-1]
    output_dataset_dir = os.path.join(data_source, 'HDF5_files', class_name)

    if not os.path.exists(output_dataset_dir):
        os.makedirs(output_dataset_dir)

    if train_dataset.load_ram:
        num_data_loader_threads = 0
    else:
        num_data_loader_threads = get_spec_with_default(
            specs, "DataLoaderThreads", 1)
    logging.debug("loading data with {} threads".format(
        num_data_loader_threads))

    train_loader = data_utils.DataLoader(
        train_dataset,
        batch_size=1,
        shuffle=False,
        num_workers=num_data_loader_threads,
    )

    train_split_file = specs["TrainSplit"]

    with open(train_split_file, "r") as f:
        train_split = json.load(f)

    data_source = specs["DataSource"]

    instance_filenames = deep_sdf.data.get_instance_filenames(data_source, train_split)

    for dataset in train_split:
        for class_name in train_split[dataset]:
            for instance_name in train_split[dataset][class_name]:
                models_dir = os.path.join(class_name, "models_without_inner_points")
                output_dir = os.path.join(data_source, obj_samples_subdir, models_dir)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for i, (xyz_data, indices) in enumerate(tqdm.tqdm(train_loader)):
        print(indices[0].item())

        if i < start_id:
            continue

        if sys.platform.startswith('linux'):
            dataset_name, class_name, instance_name = os.path.normpath(instance_filenames[i]).split("/")
        else:
            dataset_name, class_name, instance_name = os.path.normpath(instance_filenames[i]).split("\\")

        # add
        faces = xyz_data[2][0]
        verts = xyz_data[0].reshape(-1, 3)

        # if instance_name in check_list:
        mesh_dir = os.path.join(
            experiment_directory,
            ws.training_meshes_subdir,
            str(saved_model_epoch),
            dataset_name,
            class_name,
        )

        if not os.path.isdir(mesh_dir):
            os.makedirs(mesh_dir)

        mesh_filename = os.path.join(mesh_dir, instance_name)

        meshes = Meshes(verts=verts.unsqueeze(0), faces=faces.unsqueeze(0))
        sampled_mesh_points = sample_points_from_meshes(meshes, num_samples=40000)[0]

        without_inner_points = validate_inner_or_outer(sampled_mesh_points, xyz_data[3], xyz_data[4])
        print(without_inner_points.shape)

        max_points = 30000 - verts.shape[0]
        fps_idx = farthest_point_sample(without_inner_points.unsqueeze(0), max_points) # [B, npoint, C]
        print(fps_idx.shape)
        new_sampled_points = index_points(without_inner_points.unsqueeze(0), fps_idx)[0]
        all_points = torch.cat((new_sampled_points, verts), 0).numpy()
        print(all_points.shape)
        output_file = os.path.join(output_dir, instance_name.split('.')[0] + ".obj")
        # write_points_ply(mesh_filename + '_without_inner_points.ply', all_points)
        write_points_obj(output_file, all_points)
        
        if i >= end_id:
            break


if __name__ == "__main__":

    arg_parser = argparse.ArgumentParser(
        description="Use a trained DeepSDF decoder to generate a mesh given a latent code."
    )
    arg_parser.add_argument(
        "--experiment",
        "-e",
        dest="experiment_directory",
        required=True,
        help="The experiment directory which includes specifications and saved model "
        + "files to use for reconstruction",
    )
    arg_parser.add_argument(
        "--checkpoint",
        "-c",
        dest="checkpoint",
        default="latest",
        help="The checkpoint weights to use. This can be a number indicated an epoch "
        + "or 'latest' for the latest weights (this is the default)",
    )
    arg_parser.add_argument(
        "--start_id",
        dest="start_id",
        type=int,
        default=0,
        help="start_id.",
    )
    arg_parser.add_argument(
        "--end_id",
        dest="end_id",
        type=int,
        default=20,
        help="end_id.",
    )
    deep_sdf.add_common_args(arg_parser)

    args = arg_parser.parse_args()

    deep_sdf.configure_logging(args)

    mesh_to_correspondence(args.experiment_directory, args.checkpoint, args.start_id, args.end_id)
