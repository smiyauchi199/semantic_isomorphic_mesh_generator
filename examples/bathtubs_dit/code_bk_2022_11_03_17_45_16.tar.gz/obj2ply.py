import logging
import os
import sys

import numpy as np
import plyfile
import point_cloud_utils as pcu


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()

def write_ply_file(output_file, verts, faces):
    # try writing to the ply file

    num_verts = verts.shape[0]
    num_faces = faces.shape[0]

    verts_tuple = np.zeros((num_verts,), dtype=[("x", "f4"), ("y", "f4"), ("z", "f4")])

    for i in range(0, num_verts):
        verts_tuple[i] = tuple(verts[i, :])

    faces_building = []
    for i in range(0, num_faces):
        faces_building.append(((faces[i, :].tolist(),)))
    faces_tuple = np.array(faces_building, dtype=[("vertex_indices", "i4", (3,))])

    el_verts = plyfile.PlyElement.describe(verts_tuple, "vertex")
    el_faces = plyfile.PlyElement.describe(faces_tuple, "face")
    ply_data = plyfile.PlyData([el_verts, el_faces])
    logging.debug("saving mesh to %s" % (output_file))
    ply_data.write(output_file)


if __name__ == '__main__':
    args = sys.argv

    # input_file = args[1]
    # output_dir = os.path.dirname(input_file)
    exts = '.ply'

    input_dir = args[1]
    files = sorted(os.listdir(input_dir))
    input_files = [f for f in files if f[-4:] == '.obj']
    # input_files = [f for f in files if f[-4:] == '.ply']

    output_dir = 'finals'
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    output_file = output_dir + '/' + 'template_' + input_files[0].split('.')[0] + exts
    v, f = pcu.load_mesh_vf(input_dir + '/' + input_files[0])
    write_ply_file(output_file, v, f)

    # with open(input_dir + '/models.txt', 'w') as fp:

    #     for input_file in input_files:
    #         # print(input_file)
    #         # v, f = pcu.load_mesh_vf(input_dir + '/' + input_file)
    #         # # write_points_ply(output_dir + '/' + 'template_' + input_file.split('.')[0] + exts, v, faces=f)
    #         # output_file = output_dir + '/' + 'template_' + input_file.split('.')[0] + exts
    #         # write_ply_file(output_file, v, f)

    #         print(input_file)
    #         modelID = input_file.split('-', 3)[1]
    #         fp.write(modelID + '\n')
    #         v, f = pcu.load_mesh_vf(input_dir + '/' + input_file)
    #         output_file = input_dir + '/' + modelID + exts
    #         write_points_ply(output_file, v, f)
