import logging
import os
import random
# from multiprocessing import Manager, Process

import h5py
import numpy as np
import plyfile
import point_cloud_utils as pcu
import torch
import torch.nn.functional as F
import tqdm
from torch.multiprocessing import Manager, Process, set_start_method

import deep_sdf.workspace as ws


synsetID2name = {
    '04379243': 'table',
    '03593526': 'jar',
    '04225987': 'skateboard',
    '02958343': 'car',
    '02876657': 'bottle',
    '04460130': 'tower',
    '03001627': 'chair',
    '02871439': 'bookshelf',
    '02942699': 'camera',
    '02691156': 'airplane',
    '03642806': 'laptop',
    '02801938': 'basket',
    '04256520': 'sofa',
    '03624134': 'knife',
    '02946921': 'can',
    '04090263': 'rifle',
    '04468005': 'train',
    '03938244': 'pillow',
    '03636649': 'lamp',
    '02747177': 'trash bin',
    '03710193': 'mailbox',
    '04530566': 'watercraft',
    '03790512': 'motorbike',
    '03207941': 'dishwasher',
    '02828884': 'bench',
    '03948459': 'pistol',
    '04099429': 'rocket',
    '03691459': 'loudspeaker',
    '03337140': 'file cabinet',
    '02773838': 'bag',
    '02933112': 'cabinet',
    '02818832': 'bed',
    '02843684': 'birdhouse',
    '03211117': 'display',
    '03928116': 'piano',
    '03261776': 'earphone',
    '04401088': 'telephone',
    '04330267': 'stove',
    '03759954': 'microphone',
    '02924116': 'bus',
    '03797390': 'mug',
    '04074963': 'remote',
    '02808440': 'bathtub',
    '02880940': 'bowl',
    '03085013': 'keyboard',
    '03467517': 'guitar',
    '04554684': 'washer',
    '02834778': 'bicycle',
    '03325088': 'faucet',
    '04004475': 'printer',
    '02954340': 'cap',
}

obj_samples_subdir = "ShapeNetCore.v2"


def get_instance_filenames(data_source, split):
    plyfiles = []
    normparamfiles = []
    objfiles = []
    sdffiles = []
    for dataset in split:
        for class_name in split[dataset]:
            for instance_name in split[dataset][class_name]:
                # instance_filename = os.path.join(
                #     dataset, class_name, instance_name + ".ply"
                # )
                # if not os.path.isfile(
                #     os.path.join(data_source, ws.surface_samples_subdir, instance_filename)
                # ):
                #     logging.warning(
                #         "Requested non-existent file '{}'".format(instance_filename)
                #     )
                # plyfiles += [instance_filename]

                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".npz"
                )
                if not os.path.isfile(
                    os.path.join(data_source, ws.normalization_param_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                normparamfiles += [instance_filename]

                instance_filename = os.path.join(
                    class_name, "models", instance_name + ".obj"
                )
                if not os.path.isfile(
                    os.path.join(data_source, obj_samples_subdir, instance_filename)
                ):
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                objfiles += [instance_filename]

                instance_filename = os.path.join(
                    dataset, class_name, instance_name + ".npz"
                )
                if not os.path.isfile(
                    os.path.join(data_source, ws.sdf_samples_subdir, instance_filename)
                ):
                    # raise RuntimeError(
                    #     'Requested non-existent file "' + instance_filename + "'"
                    # )
                    logging.warning(
                        "Requested non-existent file '{}'".format(instance_filename)
                    )
                sdffiles += [instance_filename]

    return normparamfiles, objfiles, sdffiles


def index_points(points, idx):
    """
    Input:
        points: input points data, [B, N, C]
        idx: sample index data, [B, S]
    Return:
        new_points:, indexed points data, [B, S, C]
    """
    device = points.device
    B = points.shape[0]
    view_shape = list(idx.shape)
    view_shape[1:] = [1] * (len(view_shape) - 1)
    repeat_shape = list(idx.shape)
    repeat_shape[0] = 1
    batch_indices = torch.arange(B, dtype=torch.long).to(device).view(view_shape).repeat(repeat_shape)
    new_points = points[batch_indices, idx, :]
    return new_points


def farthest_point_sample(xyz, npoint):
    """
    Input:
        xyz: pointcloud data, [B, N, 3]
        npoint: number of samples
    Return:
        centroids: sampled pointcloud index, [B, npoint]
    """
    device = xyz.device
    B, N, C = xyz.shape
    centroids = torch.zeros(B, npoint, dtype=torch.long).to(device)
    distance = torch.ones(B, N).to(device) * 1e10
    farthest = torch.randint(0, N, (B,), dtype=torch.long).to(device)
    batch_indices = torch.arange(B, dtype=torch.long).to(device)
    for i in range(npoint):
        centroids[:, i] = farthest
        centroid = xyz[batch_indices, farthest, :].view(B, 1, 3)
        dist = torch.sum((xyz - centroid) ** 2, -1)
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = torch.max(distance, -1)[1]
    return centroids


def remove_nans(tensor):
    tensor_nan = torch.isnan(tensor[:, 3])
    return tensor[~tensor_nan, :]


class ShapeNetDataset(torch.utils.data.Dataset):

    def __init__(
        self,
        data_source,
        split,
        subsample,
        load_ram=False,
        print_filename=False,
        num_files=1000000,
    ):
        self.subsample = subsample

        self.data_source = data_source
        self.normparamfiles, self.objfiles, self.sdffiles = get_instance_filenames(data_source, split)

        logging.debug(
            "using "
            # + str(len(self.plyfiles))
            + str(len(self.normparamfiles))
            + " shapes from data source "
            + data_source
        )

        self.load_ram = load_ram

        error_list = []

        if load_ram:
            self.loaded_data = []
            for i, (normparam_f, obj_f, sdf_f) in enumerate(tqdm.tqdm(zip(self.normparamfiles, self.objfiles, self.sdffiles), ascii=True)):
                if i == 5:
                    break

                npy_filename = os.path.join(self.data_source, ws.normalization_param_subdir, normparam_f)
                npz = np.load(npy_filename)
                offset = npz['offset']
                scale = npz['scale']

                obj_filename = os.path.join(self.data_source, obj_samples_subdir, obj_f)
                try:
                    # verts, faces, _ = pcu.read_obj(obj_filename, dtype=np.float32)
                    verts, faces = pcu.load_mesh_vf(obj_filename)
                    verts = np.asarray(verts, dtype=np.float32)
                    verts = torch.from_numpy((verts + offset) * scale)
                except ValueError:
                    error_list.append(obj_filename)
                    continue

                sdf_filename = os.path.join(self.data_source, ws.sdf_samples_subdir, sdf_f)
                npz = np.load(sdf_filename)
                pos_tensor = remove_nans(torch.from_numpy(npz["pos"]))
                neg_tensor = remove_nans(torch.from_numpy(npz["neg"]))

                self.loaded_data.append(
                    [
                        verts,
                        faces,
                        pos_tensor,
                        neg_tensor,
                    ]
                )
        print(error_list)

    def unpack_data(self, data, subsample=None):
        # if subsample is None:
        #     return xyz

        # fps_idx = farthest_point_sample(xyz, subsample) # [B, npoint, C]
        # new_xyz = index_points(xyz, fps_idx)

        if subsample is None:
            return data
        pos_tensor = data[2]
        neg_tensor = data[3]
        # print(data[2])  # debug

        # split the sample into half
        half = int(subsample / 2)

        pos_size = pos_tensor.shape[0]
        neg_size = neg_tensor.shape[0]

        pos_start_ind = random.randint(0, pos_size - half)
        sample_pos = pos_tensor[pos_start_ind : (pos_start_ind + half)]

        if neg_size <= half:
            random_neg = (torch.rand(half) * neg_tensor.shape[0]).long()
            sample_neg = torch.index_select(neg_tensor, 0, random_neg)
        else:
            neg_start_ind = random.randint(0, neg_size - half)
            sample_neg = neg_tensor[neg_start_ind : (neg_start_ind + half)]

        randidx = torch.randperm(sample_pos.shape[0])
        sample_pos = torch.index_select(sample_pos, 0, randidx)
        randidx = torch.randperm(sample_neg.shape[0])
        sample_neg = torch.index_select(sample_neg, 0, randidx)

        data[2] = sample_pos
        data[3] = sample_neg

        # return new_xyz
        return data

    def __len__(self):
        # return len(self.plyfiles)
        return len(self.loaded_data)

    def __getitem__(self, idx):
        return self.unpack_data(self.loaded_data[idx], self.subsample), idx
