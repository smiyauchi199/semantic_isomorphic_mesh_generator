import json
import os
import sys
import subprocess


synsetid2name = {
    '02691156': 'airplane',
    '02808440': 'bathtub',
    # '02818832': 'bed',
    '02876657': 'bottle',
    # '02880940': 'bowl',
    '02958343': 'car',
    '03001627': 'chair',
    '03211117': 'display',
    '03624134': 'knife',
    '03948459': 'pistol',
    '04256520': 'sofa',
    '04379243': 'table',
}


if __name__ == "__main__":
    args = sys.argv

    # classID = '02818832'
    classID = args[1]

    # split_name = 's1_train'
    # split_name = 's_train'
    split_name = 's_all'

    # data_path = './data/' + classID
    data_path = '/raid/itaya/data/ShapeNetCore.v2/' + classID
    models_path = './examples/splits/' + 'sv2_' + \
        synsetid2name[classID] + split_name + '.json'

    with open(models_path, 'r') as f:
        model_list_file = json.load(f)

    for key in model_list_file.keys():
        for key2 in model_list_file[key].keys():
            model_list = model_list_file[key][key2]

    print(len(model_list))

    output_dir = os.path.join(data_path, 'model' + split_name)
    if not os.path.isdir(output_dir):
        os.mkdir(output_dir)

    for modelID in sorted(model_list):
        # print(modelID)
        model_path = os.path.join(data_path, modelID, 'models/*.obj')
        # model_path = os.path.join(data_path, 'models_train', modelID + '.obj')
        subprocess.call('cp {} {}/{}'.format(model_path,
                        output_dir, modelID + '.obj'), shell=True)
