import logging
import os
import sys

import numpy as np
import plyfile
import point_cloud_utils as pcu
from tqdm import tqdm


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8) * 169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8) * 169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


def write_ply_file(output_file, verts, faces=None):
    # try writing to the ply file

    num_verts = verts.shape[0]
    if not faces is None:
        num_faces = faces.shape[0]

    verts_tuple = np.zeros((num_verts,), dtype=[("x", "f4"), ("y", "f4"), ("z", "f4")])

    for i in range(0, num_verts):
        verts_tuple[i] = tuple(verts[i, :])
    el_verts = plyfile.PlyElement.describe(verts_tuple, "vertex")

    if not faces is None:
        faces_building = []
        for i in range(0, num_faces):
            faces_building.append(((faces[i, :].tolist(),)))
        faces_tuple = np.array(faces_building, dtype=[("vertex_indices", "i4", (3,))])
        el_faces = plyfile.PlyElement.describe(faces_tuple, "face")
        ply_data = plyfile.PlyData([el_verts, el_faces])

    ply_data = plyfile.PlyData([el_verts])
    logging.debug("saving mesh to %s" % (output_file))
    ply_data.write(output_file)


def load_ply_file(input_file, face=False):
    # load template structured mesh

    plydata = plyfile.PlyData.read(input_file)

    vs = [] #plydata.elements[0]
    for i in range(plydata.elements[0].count):
        v = plydata.elements[0][i]
        vs.append(np.array((v[0], v[1], v[2])))
    v = np.asarray(vs)

    if face:
        fs = [] #plydata.elements[1]
        for i in range(plydata.elements[1].count):
            f = plydata.elements[1][i][0]
            fs.append(np.array([f[0], f[1], f[2]]))
        f = np.asarray(fs)

    if face:
        return v, f
    else:
        return v


def fps(points, n_samples):
    """
    points: [N, 3] array containing the whole point cloud
    n_samples: samples you want in the sampled point cloud typically << N
    """
    points = np.array(points)

    # Represent the points by their indices in points
    points_left = np.arange(len(points)) # [P]

    # Initialise an array for the sampled indices
    sample_inds = np.zeros(n_samples, dtype='int') # [S]

    # Initialise distances to inf
    dists = np.ones_like(points_left) * float('inf') # [P]

    # Select a point from points by its index, save it
    selected = 0
    sample_inds[0] = points_left[selected]

    # Delete selected
    points_left = np.delete(points_left, selected) # [P - 1]

    # Iteratively select points for a maximum of n_samples
    for i in tqdm(range(1, n_samples)):
        # Find the distance to the last added point in selected
        # and all the others
        last_added = sample_inds[i-1]

        dist_to_last_added_point = (
            (points[last_added] - points[points_left])**2).sum(-1) # [P - i]

        # If closer, updated distances
        dists[points_left] = np.minimum(dist_to_last_added_point,
                                        dists[points_left]) # [P - i]

        # We want to pick the one that has the largest nearest neighbour
        # distance to the sampled points
        selected = np.argmax(dists[points_left])
        sample_inds[i] = points_left[selected]

        # Update points_left
        points_left = np.delete(points_left, selected)

    return points[sample_inds]


def main():

    args = sys.argv

    # class_name = args[1]
    # input_file = './examples/' + class_name + 's_dit/TrainingMeshes/2000/template.ply'
    # output_dir = os.path.dirname(input_file)

    input_dir = args[1]
    input_files_list = [f for f in sorted(os.listdir(input_dir)) if f[-12:] == 'position.ply']

    num_sample = int(args[2])  # 10000  # 30000

    for input_file in input_files_list:
        v = load_ply_file(input_dir + '/' + input_file)

        sampled_pts = fps(v, num_sample)
        print('sampled_pts: ', sampled_pts.shape)

        # write mesh file
        output_file = os.path.join(input_dir, input_file.split('_')[0] + '_downsampled.ply')
        # output_file = os.path.join(input_dir, input_file.split('_')[0] + '_{}downsampled.ply'.format(num_sample))
        write_ply_file(output_file, sampled_pts)


if __name__ == '__main__':
    main()

