import os
import sys
import subprocess

from tqdm import tqdm


if __name__ == "__main__":
    args = sys.argv

    # classID = '02818832'
    classID = args[1]

    # data_path = './data/' + classID
    # data_path = "/raid/itaya/data/ShapeNetCore.v2/" + classID
    # data_path = "/data1/itaya/data/ShapeNetCore.v2/" + classID
    data_path = "/mnt/nas/3DModelDataset/ShapeNet/ShapeNetCore.v2/" + classID

    model_list = os.listdir(data_path)

    output_dir = data_path + '/' + "models"
    if not os.path.isdir(output_dir):
        os.mkdir(output_dir)

    for modelID in tqdm(sorted(model_list)):
        model_path = os.path.join(data_path, modelID, 'models/*.obj')
        subprocess.call('cp {} {}/{}'.format(model_path,
                        output_dir, modelID + '.obj'), shell=True)
