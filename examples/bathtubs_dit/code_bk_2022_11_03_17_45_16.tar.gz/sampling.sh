
CUDA=${1}

# class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")
class_name_list=("bathtub" "bottle" "car" "sofa")

for name in ${class_name_list[@]};
do
  python sample_points.py examples/${name}s_dit/TrainingMeshes/2000/template.ply evaluation/templates_gt ${name} 30000
done


# names=("bathtub" "02808440" "bottle" "02876657" "car" "02958343" "chair" "03001627" "display" "03211117" "knife" "03624134" "pistol" "03948459" "sofa" "04256520" "table" "04379243")
# names=("table" "04379243")
# 
# for (( i=0; i<${#names[@]} ; i+=2 )) ; do
#   echo "${names[i]}" "${names[i+1]}"
#   CUDA_VISIBLE_DEVICES=${CUDA} python generate_canonical_positions.py -e examples/${names[i]}s_dit --start_id 0 --end_id 1999
#   python farthest_point_sampling.py examples/${names[i]}s_dit/TrainingMeshes/2000/ShapeNetV2/${names[i+1]} 10000
# done
