import os
import sys

import numpy as np
import point_cloud_utils as pcu
import torch
from scipy.spatial import distance

r = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00588235294117645, 0.02156862745098032, 0.03725490196078418, 0.05294117647058827, 0.06862745098039214, 0.084313725490196, 0.1000000000000001, 0.115686274509804, 0.1313725490196078, 0.1470588235294117, 0.1627450980392156, 0.1784313725490196, 0.1941176470588235, 0.2098039215686274, 0.2254901960784315, 0.2411764705882353, 0.2568627450980392, 0.2725490196078431, 0.2882352941176469, 0.303921568627451, 0.3196078431372549, 0.3352941176470587, 0.3509803921568628, 0.3666666666666667, 0.3823529411764706, 0.3980392156862744, 0.4137254901960783, 0.4294117647058824, 0.4450980392156862, 0.4607843137254901, 0.4764705882352942, 0.4921568627450981, 0.5078431372549019, 0.5235294117647058, 0.5392156862745097, 0.5549019607843135, 0.5705882352941174, 0.5862745098039217, 0.6019607843137256, 0.6176470588235294, 0.6333333333333333, 0.6490196078431372, 0.664705882352941, 0.6803921568627449, 0.6960784313725492,
     0.7117647058823531, 0.7274509803921569, 0.7431372549019608, 0.7588235294117647, 0.7745098039215685, 0.7901960784313724, 0.8058823529411763, 0.8215686274509801, 0.8372549019607844, 0.8529411764705883, 0.8686274509803922, 0.884313725490196, 0.8999999999999999, 0.9156862745098038, 0.9313725490196076, 0.947058823529412, 0.9627450980392158, 0.9784313725490197, 0.9941176470588236, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.9862745098039216, 0.9705882352941178, 0.9549019607843139, 0.93921568627451, 0.9235294117647062, 0.9078431372549018, 0.892156862745098, 0.8764705882352941, 0.8607843137254902, 0.8450980392156864, 0.8294117647058825, 0.8137254901960786, 0.7980392156862743, 0.7823529411764705, 0.7666666666666666, 0.7509803921568627, 0.7352941176470589, 0.719607843137255, 0.7039215686274511, 0.6882352941176473, 0.6725490196078434, 0.6568627450980391, 0.6411764705882352, 0.6254901960784314, 0.6098039215686275, 0.5941176470588236, 0.5784313725490198, 0.5627450980392159, 0.5470588235294116, 0.5313725490196077, 0.5156862745098039, 0.5]
g = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.001960784313725483, 0.01764705882352935, 0.03333333333333333, 0.0490196078431373, 0.06470588235294117, 0.08039215686274503, 0.09607843137254901, 0.111764705882353, 0.1274509803921569, 0.1431372549019607, 0.1588235294117647, 0.1745098039215687, 0.1901960784313725, 0.2058823529411764, 0.2215686274509804, 0.2372549019607844, 0.2529411764705882, 0.2686274509803921, 0.2843137254901961, 0.3, 0.3156862745098039, 0.3313725490196078, 0.3470588235294118, 0.3627450980392157, 0.3784313725490196, 0.3941176470588235, 0.4098039215686274, 0.4254901960784314, 0.4411764705882353, 0.4568627450980391, 0.4725490196078431, 0.4882352941176471, 0.503921568627451, 0.5196078431372548, 0.5352941176470587, 0.5509803921568628, 0.5666666666666667, 0.5823529411764705, 0.5980392156862746, 0.6137254901960785, 0.6294117647058823, 0.6450980392156862, 0.6607843137254901, 0.6764705882352942, 0.692156862745098, 0.7078431372549019, 0.723529411764706, 0.7392156862745098, 0.7549019607843137, 0.7705882352941176, 0.7862745098039214, 0.8019607843137255, 0.8176470588235294, 0.8333333333333333, 0.8490196078431373, 0.8647058823529412, 0.8803921568627451, 0.8960784313725489, 0.9117647058823528, 0.9274509803921569, 0.9431372549019608, 0.9588235294117646, 0.9745098039215687, 0.9901960784313726, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.9901960784313726, 0.9745098039215687, 0.9588235294117649, 0.943137254901961, 0.9274509803921571, 0.9117647058823528, 0.8960784313725489, 0.8803921568627451, 0.8647058823529412, 0.8490196078431373, 0.8333333333333335, 0.8176470588235296, 0.8019607843137253, 0.7862745098039214, 0.7705882352941176, 0.7549019607843137, 0.7392156862745098, 0.723529411764706, 0.7078431372549021, 0.6921568627450982, 0.6764705882352944, 0.6607843137254901, 0.6450980392156862, 0.6294117647058823, 0.6137254901960785, 0.5980392156862746, 0.5823529411764707, 0.5666666666666669, 0.5509803921568626, 0.5352941176470587, 0.5196078431372548, 0.503921568627451, 0.4882352941176471, 0.4725490196078432, 0.4568627450980394, 0.4411764705882355, 0.4254901960784316, 0.4098039215686273, 0.3941176470588235, 0.3784313725490196, 0.3627450980392157, 0.3470588235294119, 0.331372549019608, 0.3156862745098041, 0.2999999999999998, 0.284313725490196, 0.2686274509803921, 0.2529411764705882, 0.2372549019607844, 0.2215686274509805, 0.2058823529411766, 0.1901960784313728, 0.1745098039215689, 0.1588235294117646, 0.1431372549019607, 0.1274509803921569, 0.111764705882353, 0.09607843137254912, 0.08039215686274526, 0.06470588235294139, 0.04901960784313708, 0.03333333333333321, 0.01764705882352935, 0.001960784313725483, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
b = [0.5, 0.5156862745098039, 0.5313725490196078, 0.5470588235294118, 0.5627450980392157, 0.5784313725490196, 0.5941176470588235, 0.6098039215686275, 0.6254901960784314, 0.6411764705882352, 0.6568627450980392, 0.6725490196078432, 0.6882352941176471, 0.7039215686274509, 0.7196078431372549, 0.7352941176470589, 0.7509803921568627, 0.7666666666666666, 0.7823529411764706, 0.7980392156862746, 0.8137254901960784, 0.8294117647058823, 0.8450980392156863, 0.8607843137254902, 0.8764705882352941, 0.892156862745098, 0.907843137254902, 0.9235294117647059, 0.9392156862745098, 0.9549019607843137, 0.9705882352941176, 0.9862745098039216, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.9941176470588236, 0.9784313725490197, 0.9627450980392158, 0.9470588235294117, 0.9313725490196079, 0.915686274509804, 0.8999999999999999, 0.884313725490196, 0.8686274509803922, 0.8529411764705883, 0.8372549019607844, 0.8215686274509804, 0.8058823529411765, 0.7901960784313726, 0.7745098039215685, 0.7588235294117647, 0.7431372549019608, 0.7274509803921569, 0.7117647058823531,
     0.696078431372549, 0.6803921568627451, 0.6647058823529413, 0.6490196078431372, 0.6333333333333333, 0.6176470588235294, 0.6019607843137256, 0.5862745098039217, 0.5705882352941176, 0.5549019607843138, 0.5392156862745099, 0.5235294117647058, 0.5078431372549019, 0.4921568627450981, 0.4764705882352942, 0.4607843137254903, 0.4450980392156865, 0.4294117647058826, 0.4137254901960783, 0.3980392156862744, 0.3823529411764706, 0.3666666666666667, 0.3509803921568628, 0.335294117647059, 0.3196078431372551, 0.3039215686274508, 0.2882352941176469, 0.2725490196078431, 0.2568627450980392, 0.2411764705882353, 0.2254901960784315, 0.2098039215686276, 0.1941176470588237, 0.1784313725490199, 0.1627450980392156, 0.1470588235294117, 0.1313725490196078, 0.115686274509804, 0.1000000000000001, 0.08431372549019622, 0.06862745098039236, 0.05294117647058805, 0.03725490196078418, 0.02156862745098032, 0.00588235294117645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


def write_to_ply(filename, xyz_points, faces=None, verts_normals=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    if verts_normals is not None:
        fout.write("property float nx\n")
        fout.write("property float ny\n")
        fout.write("property float nz\n")

    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")

    if verts_normals is not None:
        for i in range(xyz_points.shape[0]):
            color = rgb_points[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
                xyz_points[i, 2]) + " " + str(verts_normals[i, 0]) + " " + str(
                    verts_normals[i, 1]) + " " + str(verts_normals[i, 2]) + " " + color + "\n")
    else:
        for i in range(xyz_points.shape[0]):
            color = rgb_points[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
                xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


if __name__ == "__main__":

    args = sys.argv

    input_file = args[1]

    sdf_data = np.load(input_file)
    sdf_pos = sdf_data['pos']
    sdf_neg = sdf_data['neg']
    xyz = np.concatenate((sdf_pos[:, :3], sdf_neg[:, :3]), axis=0)
    print(xyz.shape)
    sdf = np.concatenate((sdf_pos[:, 3], sdf_neg[:, 3]), axis=0)
    print(sdf.max(), sdf.min())
    # sdf = (sdf - sdf.min()) / (sdf.max() - sdf.min())
    normalized_sdf = (sdf - sdf.max()) / (sdf.min() - sdf.max())
    # sdf = -(sdf - sdf.max()) / 4  # if box in normalized from -2 to 2
    print(sdf.max(), sdf.min())

    values = []
    for v in normalized_sdf:
        gray = int(255 * v)
        values.append([r[gray], g[gray], b[gray]])
    values = np.array(values)
    verts_color = 255 * values
    verts_color = verts_color.astype(np.uint8)

    # output_file = input_file.split('.')[0] + "_colored.ply"
    # write_to_ply(output_file, xyz, rgb_points=verts_color)

    # verts_normals = pcu.estimate_normals(xyz, k=16)
    # verts_normals = pcu.estimate_point_cloud_normals(xyz, k=16)
    # output_path = input_file.split('.')[0] + "_normals.ply"
    # write_to_ply(output_path, xyz, verts_normals=verts_normals)

    # k = 5
    # verts_normals = pcu.estimate_point_cloud_normals(sdf_pos[:, :3], k=k)
    # output_path = input_file.split('.')[0] + "_pos_normals.ply"
    # write_to_ply(output_path, sdf_pos[:, :3], verts_normals=verts_normals)

    # verts_normals = pcu.estimate_point_cloud_normals(sdf_neg[:, :3], k=k)
    # output_path = input_file.split('.')[0] + "_neg_normals.ply"
    # write_to_ply(output_path, sdf_neg[:, :3], verts_normals=verts_normals)

    # norm_file = input_file.split('.')[0] + "_normalizationparams.npz"
    # norm_params = np.load(norm_file)
    np.random.seed(0)
    points = pcu.load_mesh_v(input_file.split('.')[0] + ".obj")
    scale_indices = (np.random.random_sample(5000) * points.shape[0]).astype(np.int32)
    print(scale_indices)
    points[scale_indices] *= 0.5
    output_file = input_file.split('.')[0] + ".ply"
    write_to_ply(output_file, points)

    # dist = distance.cdist(points, xyz, metric='euclidean')
    # dist = torch.cdist(torch.Tensor(points).cuda(), torch.Tensor(xyz[i]).cuda(), p=2)
    
    batch_split = 2
    xyz_ = torch.chunk(torch.Tensor(xyz), batch_split)
    sdf_ = torch.chunk(torch.Tensor(sdf), batch_split)
    verts_color_ = torch.chunk(torch.Tensor(verts_color), batch_split)
    points = torch.Tensor(points)
    begin_idx = 0
    nn_points = []
    nn_indices = []
    nn_colors = []
    nn_sdfs = []
    for i in range(batch_split):
        # if i == 2:
        #     break
        print(i)
        dist = torch.cdist(points.cuda(), xyz_[i].cuda(), p=2).cpu()
        indices = dist.topk(10, largest=False).indices.flatten().unique()
        nn_indices.append(indices)
        nn_points.append(xyz_[i][indices])
        nn_sdfs.append(sdf_[i][indices])
        nn_colors.append(verts_color_[i][indices])
        del dist
        begin_idx += xyz_[i].shape[0]

    nn_points = torch.cat(nn_points, 0).numpy()
    nn_indices = torch.cat(nn_indices, 0).numpy()
    # nn_colors = torch.cat(nn_colors, 0).numpy().astype(np.int8)
    nn_sdfs = torch.cat(nn_sdfs, 0).numpy()

    # output_file = input_file.split('.')[0] + "_nn_points.ply"
    # write_to_ply(output_file, nn_points)
    dist = torch.cdist(points.cuda(), torch.Tensor(nn_points).cuda(), p=2).cpu()
    indices = dist.topk(5, largest=False).indices
    # output_file = input_file.split('.')[0] + "_5nn_points.ply"
    # write_to_ply(output_file, nn_points[indices].reshape(-1, 3))

    nn_sdf = torch.Tensor(nn_sdfs[indices])
    nn_sdf = torch.where(nn_sdf > 0, 1, 0).sum(dim=1)
    inner_indices = torch.where(nn_sdf > 0, False, True).numpy()
    inner_points = points[inner_indices].numpy()
    output_file = input_file.split('.')[0] + "_inner_points.ply"
    write_to_ply(output_file, inner_points)
