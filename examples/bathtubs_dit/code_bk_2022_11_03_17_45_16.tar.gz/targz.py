import json
import os
import sys
import subprocess


synsetid2name = {
    '02691156': 'airplane',
    '02808440': 'bathtub',
    # '02818832': 'bed',
    '02876657': 'bottle',
    # '02880940': 'bowl',
    '02958343': 'car',
    '03001627': 'chair',
    '03211117': 'display',
    '03624134': 'knife',
    '03948459': 'pistol',
    '04256520': 'sofa',
    '04379243': 'table',
}


if __name__ == "__main__":
    args = sys.argv

    data_path = './data/'
    class_IDs = os.listdir(data_path)

    ignore_list = ['.DS_Store', '.datasources.json', '.datasources.json.old', '02691156']

    for classID in sorted(class_IDs):
        if classID in ignore_list:
            continue
        class_path = os.path.join(data_path, classID)
        models_dirs = os.listdir(class_path)

        for models_dir in sorted(models_dirs):
            if classID in ignore_list:
                continue
            models_dir_path = os.path.join(class_path, models_dir)
            subprocess.call('tar zcvf {} {}'.format(classID + '_' + models_dir.split('_')[1], models_dir_path), shell=True)

