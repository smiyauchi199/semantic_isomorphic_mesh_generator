import os
import matplotlib.pyplot as plt


def plot_history():

    epochs = range(1, 2001)

    pw_weights = []
    pp_weights = []
    for epoch in epochs:
        print(epoch)
        pw_weights.append(0.005 * max(1.0, 10.0 * (1 - epoch / 100)))
        pp_weights.append(0.0001 * min(1.0, epoch / 100))
        # "PointwiseLossWeight": 0.005,
        # "PointpairLossWeight": 0.0001,
        # chunk_loss = chunk_loss + pw_loss.cuda() * pointwise_loss_weight * max(1.0, 10.0 * (1 - epoch / 100))
        # chunk_loss += lp_loss.cuda() * pointpair_loss_weight * min(1.0, epoch / 100)

    # outputs directory of images
    imgs_dir = 'imgs'
    if not os.path.exists(imgs_dir):
        os.makedirs(imgs_dir)

    # save training and validation accs image
    plt.subplots()
    # plt.plot(epochs, pw_weights, label='point wise loss weight')
    plt.plot(epochs, pp_weights, label='point pair loss weight')
    plt.title('Transition of weight coefficient in DIT')
    plt.xlabel('epoch')
    plt.ylabel('weight coefficient')
    plt.legend(loc='center right')
    # img_path = os.path.join(imgs_dir, 'pw_weights.png')
    img_path = os.path.join(imgs_dir, 'pp_weights.png')
    plt.savefig(img_path)


if __name__ == "__main__":
    plot_history()
