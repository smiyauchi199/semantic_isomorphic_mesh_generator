import json
import os
import sys
import subprocess

from tqdm import tqdm


synsetid2name = {
    '02691156': 'airplane',
    '02808440': 'bathtub',
    # '02818832': 'bed',
    '02876657': 'bottle',
    # '02880940': 'bowl',
    '02958343': 'car',
    '03001627': 'chair',
    '03211117': 'display',
    '03624134': 'knife',
    '03948459': 'pistol',
    '04256520': 'sofa',
    '04379243': 'table',
}


if __name__ == "__main__":
    args = sys.argv

    class_id = args[1]
    class_name = synsetid2name[class_id]

    split_file = "./examples/splits/sv2_{}s_all.json".format(class_name)
    with open(split_file, 'r') as f:
        split_file_data = json.load(f)

    for dataset_name in split_file_data.keys():
        for class_id in split_file_data[dataset_name].keys():
            model_list = sorted(split_file_data[dataset_name][class_id])

    print(len(model_list))

    cleaning_dir = "examples/{}s_dit/TrainingMeshes/2000/ShapeNetV2/{}".format(class_name, class_id)
    # example : examples/airplanes_dit/TrainingMeshes/2000/ShapeNetV2/02691156
    data_list = sorted(os.listdir(cleaning_dir))
    tmp_cleaning_data_list = [f for f in data_list if f.split('_')[0] not in model_list[:5]]
    cleaning_data_list = [f for f in tmp_cleaning_data_list if f.split('.')[0] not in model_list[:5]]
    print(len(data_list), len(cleaning_data_list))

    for cleaning_data in tqdm(cleaning_data_list):
        cleaning_data_path = os.path.join(cleaning_dir, cleaning_data)
        # subprocess.call("rm {}".format(cleaning_data_path, shell=True))
        os.remove(cleaning_data_path)
