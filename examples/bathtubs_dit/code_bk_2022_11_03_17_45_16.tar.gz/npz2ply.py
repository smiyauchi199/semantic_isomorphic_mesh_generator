import os
import sys

import numpy as np
import point_cloud_utils as pcu


def write_points_ply(filename, xyz_points, faces=None, rgb_points=None, rgb_faces=None):
    "write ply file"

    if rgb_points is None:
        rgb_points = np.ones(xyz_points.shape).astype(np.uint8)*169

    if rgb_faces is None and faces is not None:
        rgb_faces = np.ones(faces.shape).astype(np.uint8)*169

    fout = open(filename, 'w')
    fout.write("ply\n")
    fout.write("format ascii 1.0\n")
    fout.write("element vertex " + str(xyz_points.shape[0]) + "\n")
    fout.write("property float x\n")
    fout.write("property float y\n")
    fout.write("property float z\n")
    fout.write("property uchar red\n")
    fout.write("property uchar green\n")
    fout.write("property uchar blue\n")
    if faces is not None:
        fout.write("element face " + str(len(faces)) + "\n")
        fout.write("property uchar red\n")
        fout.write("property uchar green\n")
        fout.write("property uchar blue\n")
        fout.write("property list uchar int vertex_index\n")
    fout.write("end_header\n")
    for i in range(xyz_points.shape[0]):
        color = rgb_points[i]
        color = str(color[0]) + ' ' + \
            str(color[1]) + ' ' + str(color[2])
        fout.write(str(xyz_points[i, 0]) + " " + str(xyz_points[i, 1]) + " " + str(
            xyz_points[i, 2]) + " " + color + "\n")
    if faces is not None:
        for i in range(len(faces)):
            color = rgb_faces[i]
            color = str(color[0]) + ' ' + \
                str(color[1]) + ' ' + str(color[2])
            fout.write(color + " 3 " + str(faces[i, 0]) + " " +
                       str(faces[i, 1]) + " " + str(faces[i, 2]) + "\n")

    fout.close()


if __name__ == '__main__':
    args = sys.argv

    # input_file = args[1]
    # output_dir = os.path.dirname(input_file)
    exts = '.ply'

    input_dir = args[1]
    input_files = sorted(os.listdir(input_dir))

    for input_file in input_files:
        # data = np.load(input_file)
        # print(data['pos'].shape)
        # print(data['neg'].shape)
        data = np.load(input_dir + '/' + input_file)
        if data['pos'].shape[0] <= 2500:
            print(input_file, data['pos'].shape[0])

    # write_points_ply(output_dir + '/' + os.path.basename(input_file) + exts, np.concatenate([data['pos'], data['neg']]))
    # write_points_ply(output_dir + '/' + os.path.basename(input_file) + exts, data['neg'])
