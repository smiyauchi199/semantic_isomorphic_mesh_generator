

# airplane
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_planes_train.json --skip
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_planes_test.json --skip

# car
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_cars_train.json --skip
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_cars_test.json --skip

# chair
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_chairs_train.json --skip
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_chairs1_train.json --skip
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_chairs2_train.json --skip
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_chairs_test.json --skip

# sofa
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_sofas_train.json --skip
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_sofas_test.json --skip

# table
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_tables_train.json --skip
# python preprocess_data.py --data_dir data --source ../data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_tables_test.json --skip


# class_name_list=("airplane" "bathtub" "bed" "bottle" "bowl" "car" "chair" "display" "sofa" "table")
# class_name_list=("bathtub")
class_name_list=("airplane" "bathtub" "bottle" "car" "chair" "display" "knife" "pistol" "sofa" "table")

for name in ${class_name_list[@]};
do
  # all
  # python preprocess_data.py --data_dir data --source /media/user/itaya/data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_${name}s_all.json --skip
  python preprocess_data.py --data_dir /data1/itaya/data --source /data1/itaya/data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_${name}s_all.json --skip --surface
  # train
  # python preprocess_data.py --data_dir data --source /media/user/itaya/data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_${name}s_train.json --skip
  # test
  # python preprocess_data.py --data_dir data --source /media/user/itaya/data/ShapeNetCore.v2/ --name ShapeNetV2 --split examples/splits/sv2_${name}s_test.json --skip
done
